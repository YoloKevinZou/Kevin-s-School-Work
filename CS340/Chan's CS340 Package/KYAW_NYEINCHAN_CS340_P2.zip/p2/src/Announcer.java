import java.util.Calendar;
import java.util.Random;


//THIS IS 'Announcer' Thread CLASS
public class Announcer implements Runnable
{
	public static long Startingtime = getCurrentTime();//get the currentime for time() method!
	
	public Announcer(MainClass jeopardy)
	{		
		 this.jeopardy = jeopardy;
		 this.setName(name);
		
			
	}
	private String getName()//access to name, get(return) name!
	{
			return name;
	}				
					
	private void setName(String name) //access to name, set name!
	{
		this.name=name;
	}
	//this method gives current time in milliseconds.
	public static long getCurrentTime()
	{
			return System.currentTimeMillis();
	}

	
	public void run()
	{
		while(jeopardy.running){
		try
		{
			jeopardy.contestantsSendingtheirNumbers.acquire();
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		
		AnnoucerGreeting();//announcer will be greeting
	    AnnouncerAnnouncingWhoSelectedOrEliminated();//announcer will decide and announce who get selected or not.
	    AnnouncerCreatingHostThread();//announcer will creat host thread
	    try 
		{
			Thread.sleep(new Random().nextInt(1000)+4000);
		} catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
        
      
        PrintMessage("Alirghty!...Contestants! Why don't you introduce yourself? ");
        
        jeopardy.announcerPermissionToIntroduce.release(3); //Announcer is releasing 3  contestants to introduce
        
        
        //Announcer will wait for contestants to finish introducing themselves
        try 
        {
			jeopardy.contestantsFinishedIntroducing.acquire(3);
		} catch (InterruptedException e) 
		{
			System.out.println("Interrupted from waiting, what's going on? ");
		}
        
        //create the host thread

		
        

		PrintMessage("Awesome!! Since the contestants are done introducing! It's time to welcome our host..");
		PrintMessage("Ladies and Gentlemen!!! Give it up for Mr.Thomas...our host for the evening!!!");
				
        //Annoucing release the switch so that host can move on.
        jeopardy.switchForAnnouncerHost.release();
        //at this point, Announcer has terminated.
        leave();
        jeopardy.running=false;}
	
	}//end run()
	
	
	public void AnnouncerCreatingHostThread()
	{
        Thread host=new Thread(new Host(jeopardy));//starting(initializing host thread)
		
		host.start();
	}
		
	public void AnnoucerGreeting()
	{

		PrintMessage("Ladies and Gentlemen! My name is David, your announcer and Welcome to Jeopardy Game.. ");
		PrintMessage("After receiving contestants' numbers, I'm now annoucing who get selected or rejected...");
	
	}
	
	
    @SuppressWarnings("deprecation")
	public void AnnouncerAnnouncingWhoSelectedOrEliminated()
    {
     
        Contestant c;
		//sorting it out
		for(int i=0; i<=jeopardy.contestants.size(); i++)
		{	
			for(int j=1; j<=jeopardy.contestants.size()-1; j++)
			{
					if(jeopardy.contestants.get(j-1).number< jeopardy.contestants.get(j).number)
					{
						c=jeopardy.contestants.get(j-1);
						jeopardy.contestants.set((j-1), jeopardy.contestants.get(j));
						jeopardy.contestants.set(j,c);
					}
			}	
		
	
	    }	
		

		//first announce who gets eliminated!
		int eliminated=jeopardy.contestants.size()-1;
		do 
		{
			
			PrintMessage("Sorry.."+jeopardy.contestants.get(eliminated).getName()+"...You are ELIMINATED! ");
			
			jeopardy.contestants.get(eliminated).suspend();
			eliminated--;
		}while(eliminated>=3);
		//annouce who get selected..
		int selected=0;
		do
		{
			PrintMessage("Congrats.."+jeopardy.contestants.get(selected).getName()+"...You are SELECTED! ");
			selected++;
		}while(selected<3);

		for(int i=jeopardy.contestants.size()-1; i>=3; i--)
		{
			
			jeopardy.contestants.remove(i);
			
		}
		
		
    }
	public void PrintMessage(String m)
	{
		
		System.out.println("[Printing From]"+getName()+"[time="+timeTracker()+"][age="+age()+"]"+m+"\n");
		
	}
	
	@SuppressWarnings("deprecation")
	public void leave()
	{
		Thread.currentThread().stop();
	}
	public long age()
	{
		return  System.currentTimeMillis()-Startingtime;
	}
	
	//timeTracker() method which keeps track of time.

	public String timeTracker()
	{
	//initialize time variables and get the current time:
		String time=null;
		int hour=0, minute=0, second=0, millisecond=0;
		Calendar currentTime = Calendar.getInstance();
		currentTime.setTimeInMillis(System.currentTimeMillis());
		//set the variables to the current time
		hour=currentTime.get(Calendar.HOUR);
	    if(hour==0)
    	{ 	hour=12; 	}
	    minute=currentTime.get(Calendar.MINUTE);
	    second=currentTime.get(Calendar.SECOND);
	    millisecond=currentTime.get(Calendar.MILLISECOND); 
	
	    //calculate the hour
		if(hour<10)
		{ 	time=("0"+ hour);}
		else if(hour>=10)
		{	time=(""+hour);}
			time=time.concat(":");
			//calculate the minute:
		if(minute<10)
		{	time=time.concat("0"+minute);}
	
		else if(minute>=10)
		{	time=time.concat(""+minute);	}
			time=time.concat(":");
			//calculate the second:
		if(second<10)
		{	time=time.concat("0"+second); }
		else if(second>=10)
		{	time=time.concat(""+second); }
			time=time.concat(".");
			//calculate the millisecond
		if(millisecond<10)
		{	time=time.concat("0"+millisecond); }
		else if(millisecond>=10)
		{ 	time=time.concat(""+millisecond); }
			time=time.concat(" ");
			return time;
		}
	
	
	MainClass jeopardy;
	String name="Announcer";
	
}//end of the  Announcer class
