import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Random;


//THIS IS 'Host' Thread CLASS
public class Host implements Runnable
	{
	    public static long Startingtime = getCurrentTime();//get the currentime for time() method!
		public Host(MainClass jeopardy)
		{		
			this.jeopardy = jeopardy;
			this.setName(name);
		}
		
		private String getName() 
		{	
			return name;
		}
		private void setName(String name) 
		{
			this.name=name;
			
		}

		public static long getCurrentTime()
		{
			return System.currentTimeMillis();
		}

	    public void run()
	    {
		while(jeopardy.running){
		 try
		   {
				Thread.sleep(3500);
		   } catch (InterruptedException e)
		   { 
			    System.out.println("Somebody interrupted me?");
		   }

			//host is waiting for the switch to be released
		 try {
			jeopardy.switchForAnnouncerHost.acquire();
		 } catch (InterruptedException e) 
		 {
			
			e.printStackTrace();
		 }
		    HostGreeting();//host will introduce himself
		
		    HostAskingQuestionsToContestants();//host will start the game asking questions and checking answers.
		
		 try 
		 {
		  	Thread.sleep(new Random().nextInt(1000)+4000);
		 }  catch (InterruptedException e) 
		 {
			e.printStackTrace();
		 }
				
		    jeopardy.setEndSignalRound();//it's the end of the rounds and time to advace to the final.
			
		    HostPerformingFinal();//host will take care final, asking question and grading for winner.

	        leave();//host is leaving..
		    jeopardy.running=false;}
		
	}//end run()
	public void HostGreeting()
	{

		 PrintMessage("Thank you, Mr. Thomas! I'm so excited!");
		 PrintMessage("Hello, Everybody! My name is Thomas, the host for the game and Welcome to the show ");
		 PrintMessage("Are you ready.. contestants? Let's start the game !!! ");
	}
	
	public void HostAskingQuestionsToContestants()
	{
		   
		counterForQuestion=0;
		int contestatntIndex=0;
		do
		{
			PrintMessage("******************Round number="+(jeopardy.counterForRound+1)+"*****************");
			
			do
			{
				
				PrintMessage("[Host asking the qestion number="+counterForQuestion+"]");
				//random contstant will answer the question.
				contestatntIndex = new Random().nextInt(3);
				try {
	   				Thread.sleep(new Random().nextInt(1000)+2500);
	   			} catch (InterruptedException e) 
	   			{
	   				e.printStackTrace();
	   			}
				jeopardy.contestants.get(contestatntIndex).interrupt();
				
				 //waiting for for the first contestant to answer the quetsion.
				try {
					jeopardy.contestantGivingAnswer.acquire();
				} catch (InterruptedException e) 
				{	e.printStackTrace();
				}
				//Once the question is answer, host will generate random number
				//in order to decide if the anwerse is correct or not.
				//this makes use of the rightPercent variable.
				double randPercent = generator.nextDouble() * 1.0;
				PrintMessage("RIGHT AMOUNT CALCULATED FOR=>"+jeopardy.contestants.get(contestatntIndex).getName()+"="+dec.format(randPercent)+"]");
	   			if(randPercent < jeopardy.rightPercent)
	   			{
	   				PrintMessage("You just answered the incorrect answer!! "+jeopardy.contestants.get(contestatntIndex).getName());
	   				PrintMessage("Sorry but "+jeopardy.questionValues+" points is deducted from your total score.");
	   				//host update the contestant's score
	   				jeopardy.contestants.get(contestatntIndex).scorePoint-=jeopardy.questionValues;
	   				
	   			}else{
	   				
	   				PrintMessage("That's CORRECT!!! "+jeopardy.contestants.get(contestatntIndex).getName());
	   				PrintMessage("So that "+jeopardy.questionValues+" points is added to your total score.");
	   				//host update the contestant's score
	   				jeopardy.contestants.get(contestatntIndex).scorePoint-=jeopardy.questionValues;
	   			}

				counterForQuestion++;
			}while(counterForQuestion<=jeopardy.numQuestions);
			


			counterForQuestion=1;
			jeopardy.counterForRound++;
		}while(jeopardy.counterForRound<=jeopardy.numRounds);
	}
	
	@SuppressWarnings({ "deprecation" })
	public void HostPerformingFinal()
	{
		PrintMessage("Contestants! We are done with the rounds and I need you guys to calulate your score points!!");
		PrintMessage("[Host asking Contestants to calculate their balances]");
	    
		//rest for a while since  contestants are calculating their balances
		 try 
		    {
		     	Thread.sleep(new Random().nextInt(1000)+4000);
		    } catch (InterruptedException e) 
		    {
		    	e.printStackTrace();
		    }
		PrintMessage("Contestants! Now, it's time for FINAL jeopardy!!!");
		//only those contestants are returning after picking up their wager amount
		PrintMessage("The follwing are those who have qualified for finals");
		 
		//contestants with positive score will qualify to play the final and 
		   
		   int counterForFinalContestants=0;
		  do {
			   if(jeopardy.contestants.get(counterForFinalContestants).isAlive())
			   {
				   
				   PrintMessage(counterForFinalContestants+1+"-"+jeopardy.contestants.get(counterForFinalContestants).getName());
				   counterForFinalContestants++;
			   }
			   counterForFinalContestants++; 	   
		   }while(counterForFinalContestants<3);
		   PrintMessage("[The host asks the final question]");
	    for(int i=0; i<3; i++)
	    {
	    
	    	jeopardy.hostPermissionToContestants.release();
	    	try {
	    		
	    		jeopardy.mutex2ForContestants.acquire();
	    	} catch (InterruptedException e) 
	    	{
	    		e.printStackTrace();
	    	}
	    	
	    }
	    //the host is carefully grading the answers for final round.
		for(int i=0; i<3; i++)
		{
		    if(jeopardy.contestants.get(i).scorePoint>0)
		    {
				 if(new Random().nextInt(100)>50)
				 { 
					  jeopardy.contestants.get(i).scorePoint+=jeopardy.contestants.get(i).wagerAmount;
					  PrintMessage(jeopardy.contestants.get(i).getName()+" got the correct answer. "+jeopardy.contestants.get(i).wagerAmount
							+" will be added to the score."+" And now the total score is: "+jeopardy.contestants.get(i).scorePoint);
					 
				  }else
				  {
					  jeopardy.contestants.get(i).scorePoint-=jeopardy.contestants.get(i).wagerAmount;
					  PrintMessage(jeopardy.contestants.get(i).getName()+" got the wrong answer. "+jeopardy.contestants.get(i).wagerAmount
						+" will be deducted from the score."+" And now the total score is: "+jeopardy.contestants.get(i).scorePoint);
				  }
			  }
		  }
		
	    winnerIndex=0;
	    winnerScore=0;
	    for(int i=1; i<3; i++)
	    {
	    	
	    	if(jeopardy.contestants.get(winnerIndex).scorePoint<jeopardy.contestants.get(i).scorePoint)
	    	{
	    		winnerIndex=i;
	    	    winnerScore=jeopardy.contestants.get(i).scorePoint; 
	    	}
	    	
	    }
	   
		   //the host will print the scores and announce the winner.
		   PrintMessage("Ladies and Gentlemen! Let's give it up for our winner: "+jeopardy.contestants.get(winnerIndex).getName()+"[ score points="+winnerScore+ "]");
		   
	       //once complete the host will say good bye and terminate.
		   PrintMessage(" Thank you so much for watching this show. Good Bye.");
          
		   for(int i=0;i<3;i++)
		   {
			   if(jeopardy.contestants.get(i).isAlive())
				   jeopardy.contestants.get(i).stop();
			       
		   }
		   		
		   		
			
	}	
	


		

	public void PrintMessage(String m)
	{
		
		System.out.println("[Printing From]"+getName()+"[time="+timeTracker()+"][age="+age()+"]"+m+"\n");
		
	}
	
	@SuppressWarnings("deprecation")
	public void leave()
	{
		Thread.currentThread().stop();
	}
	public long age()
	{
		return  System.currentTimeMillis()-Startingtime;
	}
	public String timeTracker()
	{
	//initialize time variables and get the current time:
		String time=null;
		int hour=0, minute=0, second=0, millisecond=0;
		Calendar currentTime = Calendar.getInstance();
		currentTime.setTimeInMillis(System.currentTimeMillis());
		//set the variables to the current time
		hour=currentTime.get(Calendar.HOUR);
	    if(hour==0)
    	{ 	hour=12; 	}
	    minute=currentTime.get(Calendar.MINUTE);
	    second=currentTime.get(Calendar.SECOND);
	    millisecond=currentTime.get(Calendar.MILLISECOND); 
	
	    //calculate the hour
		if(hour<10)
		{ 	time=("0"+ hour);}
		else if(hour>=10)
		{	time=(""+hour);}
			time=time.concat(":");
			//calculate the minute:
		if(minute<10)
		{	time=time.concat("0"+minute);}
	
		else if(minute>=10)
		{	time=time.concat(""+minute);	}
			time=time.concat(":");
			//calculate the second:
		if(second<10)
		{	time=time.concat("0"+second); }
		else if(second>=10)
		{	time=time.concat(""+second); }
			time=time.concat(".");
			//calculate the millisecond
		if(millisecond<10)
		{	time=time.concat("0"+millisecond); }
		else if(millisecond>=10)
		{ 	time=time.concat(""+millisecond); }
			time=time.concat(" ");
			return time;
	}
	
	
	
	
	public MainClass jeopardy;
	private String name = "Host";
	public int counterForQuestion;//that will keep track of counter for question.
	public int counterForFinalContestants;//that will tell how many contestants qualify for final
	Random generator = new Random();
	DecimalFormat dec = new DecimalFormat("#.##");  
	int randomNo, winnerIndex,winnerScore;


}//end of the Host Class

