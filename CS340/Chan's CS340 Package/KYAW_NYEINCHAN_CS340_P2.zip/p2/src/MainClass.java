import java.util.Vector;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
/*Class= CSCI 340 , Project Name= Project Two (Using Semaphores) Written By Nyein chan kyaw (ID-12121670)*/
public class MainClass
{
	public MainClass()
	{
		   
		numContestant=7; //Initially 7 contestants
		counterForContestant=0;//used to check for calculating their numbers
		numRounds=3;//there are 3 rounds
		counterForRound=0;
		numQuestions=6;
		questionValues=200;
		rightPercent=0.70;
		running=true;
		resetEndSignalRound();
		priority=10;//by deafult..//MAX_PRIORITY
		introduce();//shared  introduce method()
		
		//intially, we need to to have 1 and set it true, so that first contestant can get the lock!
		mutexForContestants=new Semaphore(1,true); 
		//contestantsSendingtheirNumbers will be used to notify Announcer so that he can say who qualified or not!
		contestantsSendingtheirNumbers=new Semaphore(0); 
		//a counting semaphore that needs to acquired for contestants to introduce.
		announcerPermissionToIntroduce=new Semaphore(0); 
		//this semaphore will be used to notify that contestants are done introducing.
		//we will use it as counting semaphore, so that it will wait three qualified contestants and introduce.
		contestantsFinishedIntroducing=new Semaphore(0); 
		switchForAnnouncerHost=new Semaphore(0);//annoucer will release it , host needs to wait for it .
		contestantGivingAnswer=new Semaphore(0);//in rounds, host is expecting an answer from contestants. used as binary semaphore.
		
		 
		//a counting semphore that needs to be relased from host to contestants.
		hostPermissionToContestants=new Semaphore(0); 
		
		
		//another mutex for contestants for final.
		mutex2ForContestants=new Semaphore(0);
			
					
	}
		
	public static void main(String[] args)
	{

    	MainClass jeopardy = new MainClass();
		//while(jeopardy.running)
	      {	
	      try{
		    //these values can be changed from command lines!
		  /* 
		   	jeopardy.numRounds=Integer.parseInt(args[0]);//@param args[0] - the number of rounds per game
		   	jeopardy.numQuestions=Integer.parseInt(args[1]);// @param args[1] - the number of questions per round
		   	jeopardy.questionValue=Integer.parseInt(args[2]);// @param args[2] - the number of points per question
		    jeopardy.rightPercent=Double.parseDouble(args[3]);//@param args[3] - the percentage for the contestants
		     
		    */
			
	  		System.out.println("....................................................................");
			System.out.println("....................Welcome to Jeopardy Game........................");
			System.out.println("....................................................................");

			System.out.println("Below are the results of contestants' computed numbers ");
		    
	   
			//7 contestants threads will be created! using makeContestantsThreads method. 
			jeopardy.makeContestantsThreads(jeopardy);

			//Annoucer thread will be created!
			new Thread(new Announcer(jeopardy)).start();}//starting(initializing) announcer thread!
		    
	      	catch(Exception e){ System.out.println("Invalid parameters!!!"); };
		    
	      }    	
	     
}//end run()
		

    public void makeContestantsThreads(MainClass j)
	 {
		
		 
		 j.contestants = new Vector<Contestant>(j.numContestant);
		 
		 int i=0;
		do {
			 
			 j.contestants.add(new Contestant(j,i));
			 i++;
		 }while( i<j.numContestant);
		 
		 int k=0;
		 do 
		 {
			 
			 j.contestants.get(k).start();
			 k++;
		 }while(k<j.numContestant); 
		 
	 }
	 public  void increase_counterForContestant()
	 {
		 
		 counterForContestant++;
	 }
	 public boolean getEndSignalRound()
	 {
		 return endSignalRound;
	 }
	 public void setEndSignalRound()
	 {
		  endSignalRound=true;
	 }
	 
	 public void resetEndSignalRound()
	 {
		  endSignalRound=false;
	 }
	 static Announcer announcer;
	 static Contestant[] contestant;
	//important default vairables 
	 int numContestant, numRounds, numQuestions, questionValues;
	 double rightPercent;
	 public boolean endSignalRound;
	 //counters
	 int counterForContestant,counterForRound;
	
	 public volatile boolean running;
	 int priority;//priority for contestants threads! 
	 
	//String method introduce will be shared among contestants to introduce themselves.!
	 public String introduce() 
	 {
	    	 return "Hello, EveryOne! I'm glad to be here. My name is ";
			
	 }
	 //a binary semaphore when contestants finish calculating their numbers, contestantsSendingtheirNumbers will be released. 
    Semaphore contestantsSendingtheirNumbers;
	//mutexForContestants is a mutex for contestants to update counters accurately.
	Semaphore mutexForContestants;
	//a binary semaphore used to notify to host that answer is just delivered.
	Semaphore contestantGivingAnswer;
	//a counting semaphore that needs to acquired for contestants to introduce.
	Semaphore announcerPermissionToIntroduce;
	//we will use it as counting semaphore, so that it will wait three qualified contestants and introduce.
	Semaphore contestantsFinishedIntroducing;
	Semaphore switchForAnnouncerHost;
	 
	//a counting semphore that needs to be relased from host to contestants.
	Semaphore hostPermissionToContestants;
	//another mutex for contestants for final.
	Semaphore mutex2ForContestants;
	Vector<Contestant> contestants;
	
	 
	 

}//end of the MainClass
