import java.util.Calendar;
import java.util.Random;


//THIS IS 'Contestant' Thread CLASS
public class Contestant extends Thread 
{

	public long startingTime=getCurrentTime();//get the currentime for time() method!
	public Contestant(MainClass jeopardy,int id)
	{
		this.jeopardy = jeopardy;
		this.setName((new StringBuilder("Contestant ")).append(id).toString());
	}
   	
	public void run()
	{

	        contestantsCalculatingTheirNumbers();//contestants are now calculating their random numbers.
		
		  
	        try 
		    {
		     	Thread.sleep(new Random().nextInt(1000)+4000);
		    } catch (InterruptedException e) 
		    {
		    	e.printStackTrace();
		    }


		    try
		    {
				jeopardy.announcerPermissionToIntroduce.acquire();
			} catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		    

			
			try 
			{
				Thread.sleep(new Random().nextInt(1000)+4000);
			} catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
			//contestants will be introducing themselves.
		    contestantsIntrducingThemselves();
		    jeopardy.contestantsFinishedIntroducing.release();
		    //contestants will be playing in the game.
		    contestantsParticipating();
		    //contestants will be calculating their scores and play the final round.
		    contestantsCalculatingScores();
		    
		  
		
	}//end run()
	public void  contestantsCalculatingTheirNumbers()
	{
		number = new Random().nextInt(100);//contestants generating random numbers			
	
	    try{
		    jeopardy.mutexForContestants.acquire();
		    jeopardy.increase_counterForContestant();
	    	PrintMessage("Hi..my computed number is "+number);
	       }catch(InterruptedException e)
     	 { System.out.println( Thread.currentThread()+" gets interrupted!");}
		
		//checking if contestants done with computing!						
		if(jeopardy.counterForContestant==jeopardy.numContestant)
		{		
			jeopardy.mutexForContestants.release();
			jeopardy.contestantsSendingtheirNumbers.release(); 
	    	
		}	
		else{
			jeopardy.mutexForContestants.release();
		}
		
	
	}		
	public void contestantsIntrducingThemselves()
	{

	    NamePrintMessage(jeopardy.introduce());
	}
	
	public void contestantsParticipating()
	{
		
		do{
		    
	    	try {
	    		jeopardy.hostPermissionToContestants.acquire();
	    	} catch (InterruptedException e) 
	    	{
	    		//e.printStackTrace();
	    	}
	    	if(!jeopardy.endSignalRound)
	    		PrintMessage("[Contestant answering question!] I pick no-"+new Random().nextInt(2)+ " for answer");
	    	
	    	try {
				sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 
	    	jeopardy.contestantGivingAnswer.release();
	    }while(!jeopardy.endSignalRound);
	   
	
		
		
		
		
	}
	private void contestantsCalculatingScores() 
	{
		if(scorePoint>0)
		{
	    	
          	wagerAmount = new Random().nextInt(scorePoint);
          	PrintMessage("has score: "+scorePoint+" and choose wager to "+wagerAmount);	
          	PrintMessage("has finished answering the final question.");
          	jeopardy.mutex2ForContestants.release();    	
		    	
		    }else
		    {
		    	
		    	PrintMessage(" has negative score and leaves the game.");
		    	jeopardy.mutex2ForContestants.release(); 
		    	
		    }
		    
  
		    
	}

	public long getCurrentTime()
	{
		return System.currentTimeMillis();
	}
	
	public synchronized void NamePrintMessage(String m)
	{
		String[] name={"David","Steven","Eric","Lily", "Tony","Jacob","Susan","William","Bob","Tyson"};
		int rand = new Random().nextInt(9);	
	
		System.out.print("[Printing From]"+getName()+"[time="+timeTracker()+"][age= "+age()+"]"+m+name[rand]+"\n" );
		
	

	}
	
	
	public synchronized void PrintMessage(String m)
	{
		
		System.out.println("[Printing From]"+getName()+"[time="+timeTracker()+"][age="+age()+"]"+m+"\n");
		
	}
	
	public long age()
	{
		return  System.currentTimeMillis()-startingTime;
	}

	
	public String timeTracker()
	{
	//initialize time variables and get the current time:
		String time=null;
		int hour=0, minute=0, second=0, millisecond=0;
		Calendar currentTime = Calendar.getInstance();
		currentTime.setTimeInMillis(System.currentTimeMillis());
		//set the variables to the current time
		hour=currentTime.get(Calendar.HOUR);
	    if(hour==0)
    	{ 	hour=12; 	}
	    minute=currentTime.get(Calendar.MINUTE);
	    second=currentTime.get(Calendar.SECOND);
	    millisecond=currentTime.get(Calendar.MILLISECOND); 
	
	    //calculate the hour
		if(hour<10)
		{ 	time=("0"+ hour);}
		else if(hour>=10)
		{	time=(""+hour);}
			time=time.concat(":");
			//calculate the minute:
		if(minute<10)
		{	time=time.concat("0"+minute);}
	
		else if(minute>=10)
		{	time=time.concat(""+minute);	}
			time=time.concat(":");
			//calculate the second:
		if(second<10)
		{	time=time.concat("0"+second); }
		else if(second>=10)
		{	time=time.concat(""+second); }
			time=time.concat(".");
			//calculate the millisecond
		if(millisecond<10)
		{	time=time.concat("0"+millisecond); }
		else if(millisecond>=10)
		{ 	time=time.concat(""+millisecond); }
			time=time.concat(" ");
			return time;
	}
	
	
	
	 MainClass jeopardy;
	 int number=0;
	 int scorePoint=0;
	 int wagerAmount=0;
	
	

}//end of the Contestant class

