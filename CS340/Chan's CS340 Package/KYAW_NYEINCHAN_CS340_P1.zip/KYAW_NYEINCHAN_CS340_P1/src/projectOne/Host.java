package projectOne;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Random;
//import java.util.Scanner;
import java.util.concurrent.BrokenBarrierException;

//THIS IS 'Host' Thread CLASS

public class Host implements Runnable
{
	public static long Startingtime = getCurrentTime();//get the currenttime for time() method!
	
	
	public Host(MainClass jeopardy)
	{		
		this.jeopardy = jeopardy;
		this.setName(name);
	}
	
	private String getName() 
	{	
		return name;
	}
	private void setName(String name) 
	{
		this.name=name;
		
	}

	public static long getCurrentTime()
	{
		return System.currentTimeMillis();
	}
	
	//the run method for the Host thread. 
	@SuppressWarnings("deprecation")
	public void run()
	{
		 
		//while(jeopardy.running)
		{	
		   //Host sleeping(busy waiting) for long period. until Annnocer interrupts him from sleep.
			try
		   {
				Thread.sleep(500000);
		   } catch (InterruptedException e1)
		   { 
			   //when Annoucner interrupts Host, by 'host.interrupt'..the following should print out.
			   /*if(Thread.interrupted())  				   
			   PrintMessage("Hello, Everybody! This is your host: Thomas, Welcome to the show "); 	*/

			   PrintMessage("Thanks, David!! Hello, Everybody! This is your host: Thomas, Welcome to the show of Jeopardy!!!");  	
		   }	
		    
		   //let Announcer to continue finishing his final words. 
			
		   jeopardy.set_oksignalAnnouncer();
		   //host will busy wait til Announcer sets oksignalHost to 'true'
		   do
		   {
			   try {
				Thread.sleep(150);
			} catch (InterruptedException e) 
			{
				
				PrintMessage("Host is interrupted");
			}
		   } while(!jeopardy.get_oksignalHost());
		   };
		   //oksignalHost is set to true by Announcer! Host will continue..!
		   //rounds are about to start
		   //for each question the following steps will be taken.

		   PrintMessage("yes, David! are you ready.. contestants? Now, the game is officially started! ");
	       do	
		   {

			    PrintMessage("*************************************************");
			    PrintMessage("******************Round number="+(jeopardy.counterForRound+1)+"*****************");
			    PrintMessage("*************************************************");
			    counterForQuestion=1; 
			   		while(counterForQuestion<=jeopardy.numQuestions)
			   		{
			   			jeopardy.oksignalAnswer=false;
			   			PrintMessage("[Host asking the qestion number="+counterForQuestion+"]");
			   			//sleep for random time to allow for Contestants to think
			   			try {
			   				Thread.sleep(new Random().nextInt(1000)+2500);
			   			} catch (InterruptedException e) 
			   			{
			   				e.printStackTrace();
			   			}
			   			//Radomly determine which Contestant should exit the busy waiting and
			   			//answer the question. Just One at a time, thus, notify() will be used.
			   			 jeopardy.Notify();
			   			  
			   			 //host will busy wait until the question is answered.
						try {
							Thread.sleep(5000);
						} catch (InterruptedException e)
						{
							e.printStackTrace();
						}while(jeopardy.oksignalAnswer==false);
			   		  
						//Once the question is answer, host will generate random number
						//in order to decide if the anwerse is correct or not.
						//this makes use of the rightPercent variable.
						double randPercent = generator.nextDouble() * 1.0;
						PrintMessage("[RIGHT AMOUNT CALCULATED FOR ]"+MainClass.contestant[jeopardy.activeThread].getName()+"="+dec.format(randPercent)+"]");
			   			if(randPercent< jeopardy.rightPercent)
			   			{
			   				//if random no is less thatn rightPercent
			   				//then, print out ...wrong answer. 
			   				
			   				PrintMessage("You just answered the incorrect answer!! "+MainClass.contestant[jeopardy.activeThread].getName());
			   				PrintMessage("Sorry but "+jeopardy.questionValues+" points is deducted from your total score.");
			   				//host update the contestant's score
			   				MainClass.contestant[jeopardy.activeThread].decrease_scorePoint();
			   				
			   			}
			   			else
			   			{
                              //otherwise he is right.
			   				PrintMessage("Yes!!!you just answered the correct answer!! "+MainClass.contestant[jeopardy.activeThread].getName());
			   				PrintMessage("Therefore, "+jeopardy.questionValues+" points is added to your total score.");
			   			    //host update the contestant's score
			   				MainClass.contestant[jeopardy.activeThread].increase_scorePoint();

			   				
			   			}
    
			   			counterForQuestion++;
			   			}//end of each round
			         //print out that a round is finished
			   		PrintMessage("Round number="+(jeopardy.counterForRound+1)+" finished");
			        //increase counterForRound to start a new round.
			   		jeopardy.increase_counterForRound();
			   		
		   	} while(jeopardy.counterForRound<jeopardy.numRounds);//repeat
		   
	       
		   //at this point, all rounds have been played
	       //it is time for Final jeopardy.
              
			
			jeopardy.reset_oksignalHost();
           //when endsignalRound is set to 'true' then contestants will continue 
		   jeopardy.set_endsignalRound();
		   PrintMessage("Contestants! Now, it's time for FINAL jeopardy!!!");
		   PrintMessage("[Host asking Contestants to calculate their balances]");
		   //
		   
		   try {
			jeopardy.NotifyAll();
		   } catch (InterruptedException e)
		   {
			   e.printStackTrace();
		   }       		   
		 //let contestants busy wait while calculating their balances
		   try {
			try {
				jeopardy.barrier2.await();
			} catch (BrokenBarrierException e)
			{
				
			}
		} catch (InterruptedException e)
		{

			e.printStackTrace();
		}
           //only those contesstants are returning after picking up their wager amount
		   PrintMessage("The follwing are those who have qualified for finals");
		 
		   //contestants with positive score will qualify to play the final and 
		   //
		   for(int i=0;i<3;i++)
		   {
			   if(MainClass.contestant[i].isAlive())
			   {
				   
				   PrintMessage(i+1+"-"+MainClass.contestant[i].getName());
				   counterForFinalContestants++;
			   }
			   	   
		   }//end for
		   PrintMessage("There are "+counterForFinalContestants+" contestants will be participating in final round");
		   PrintMessage("[The host asks the final question]");
		  //notify all the contestants to answer the question
		 try 
		   {
			
			   jeopardy.NotifyAll();
		} catch (InterruptedException e1)
		{
			e1.printStackTrace();
		}
		   //wait for for the first contestant to answer the quetsion.
		   
	 try {
			jeopardy.Wait();
		} catch (InterruptedException e1)
		{
			e1.printStackTrace();
		}  
		  // the first contestant that wakes up will leave only after 
	     //second one that waits up and terminates
		   for(int i=0; i<3; i++)
		   {		   
			   if(MainClass.contestant[i].isAlive())
			   {			   
				   	try {
				   		MainClass.contestant[i].join();
				   	} catch (InterruptedException e) 
				   	{
						
				   		e.printStackTrace();
				   	}
			   }	   
		   }
		   /*try
        	{
    	     	Thread.sleep(1000);
    	    	jeopardy.Notify();//notify the contestant
       	}catch(Exception e){}*/

		   /*
		while(!jeopardy.oksignalHost)
		{
			try{
				Thread.sleep(10000);
			}catch(Exception e){}
		}
		*/
		
		//now time for host to determine the winner
		   //The host randomly determines who has the right score for final question
		  for(int i=0; i<3; i++)
		  {
			  randomNo=new Random().nextInt();
			  if(MainClass.contestant[i].scorePoint>0)
			  {
				  //contestant will randomly get the last question right or wrong with 50% chance
				  if(randomNo>50)
				  {
					  PrintMessage("After calulating the score for the final question "+MainClass.contestant[i].getName()+" got the correct answer. ");
					  PrintMessage(MainClass.contestant[i].wagerAmount+" will now added to the total score");
					  MainClass.contestant[i].scorePoint+=MainClass.contestant[i].wagerAmount;
				  }
			  }
		  }
		  
		  //announce who is the winner who got the hightest total score
		 //computeWinner();
		  winnerIndex=0;
		  winnerScore=MainClass.contestant[0].scorePoint;
		  for(int i=1; i<3; i++)
		  {
			  
			  if(MainClass.contestant[i].scorePoint>winnerScore)
			  {
				  	winnerIndex=i;
				  	winnerScore=MainClass.contestant[i].scorePoint;	  
			  } 
		  }
		   //the host will print the scores and announce the winner.
		   PrintMessage("Ladies and Gentlemen! Let's give it up for our winner: "+MainClass.contestant[winnerIndex].getName()+"[ score points="+MainClass.contestant[winnerIndex].scorePoint+ "]");
		   
	       //once complete the host will say good bye and terminate.
		   PrintMessage(" Thank you so much for watching this show. Good Bye.");

		   for(int i=0;i<3;i++)
		   {
			   if(MainClass.contestant[i].isAlive())
				   MainClass.contestant[i].suspend();}
		   		// PrintMessage("press Enter to quit");
		   			
			
		        Thread.currentThread().suspend();
			}	
	
	// end run method of Host
	

	public synchronized void PrintMessage(String m)
	{
		
		System.out.println("[Printing From]"+getName()+"[time="+timeTracker()+"][age="+age()+"]"+m+"\n");
		
	}
	
	
	public long age()
	{
		return  System.currentTimeMillis()-Startingtime;
	}
	public String timeTracker()
	{
	//initialize time variables and get the current time:
		String time=null;
		int hour=0, minute=0, second=0, millisecond=0;
		Calendar currentTime = Calendar.getInstance();
		currentTime.setTimeInMillis(System.currentTimeMillis());
		//set the variables to the current time
		hour=currentTime.get(Calendar.HOUR);
	    if(hour==0)
    	{ 	hour=12; 	}
	    minute=currentTime.get(Calendar.MINUTE);
	    second=currentTime.get(Calendar.SECOND);
	    millisecond=currentTime.get(Calendar.MILLISECOND); 
	
	    //calculate the hour
		if(hour<10)
		{ 	time=("0"+ hour);}
		else if(hour>=10)
		{	time=(""+hour);}
			time=time.concat(":");
			//calculate the minute:
		if(minute<10)
		{	time=time.concat("0"+minute);}
	
		else if(minute>=10)
		{	time=time.concat(""+minute);	}
			time=time.concat(":");
			//calculate the second:
		if(second<10)
		{	time=time.concat("0"+second); }
		else if(second>=10)
		{	time=time.concat(""+second); }
			time=time.concat(".");
			//calculate the millisecond
		if(millisecond<10)
		{	time=time.concat("0"+millisecond); }
		else if(millisecond>=10)
		{ 	time=time.concat(""+millisecond); }
			time=time.concat(" ");
			return time;
	}
	
		public MainClass jeopardy;
		private String name = "Host";
		public int counterForQuestion;//that will keep track of counter for question.
		public int counterForFinalContestants;//that will tell how many contestants qualify for final
		//creating Contestant[] instance
		Contestant[] contestant;
		//creating Contestant array for those who get qualified for final qestion
		Contestant[] contestantForFinal;
		Random generator = new Random();
		DecimalFormat dec = new DecimalFormat("#.##");  
		int randomNo, winnerIndex,winnerScore;
	
}
