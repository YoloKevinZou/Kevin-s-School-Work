package projectOne;
//import java.util.Scanner;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class MainClass
{

	public MainClass()
	{  

	    t=Executors.newCachedThreadPool();
	    barrier1 = new CyclicBarrier(3);
		barrier2= new CyclicBarrier(3);
		numContestant=7; //Initially 7 contestants
		counterForContestant=0;//used to check for calculating their numbers
		numRounds=3;//there are 3 rounds
		counterForRound=0;
		numQuestions=6;
		questionValues=200;
		rightPercent=0.70;
		running=true;
		oksignalContestant=false;
		oksignalAnnouncer=false;
		endsignalRound=false;
		oksignalAnswer=false;
		oksignalFirst=true;
		priority=10;//by deafult..//MAX_PRIORITY
		//shared  introduce method()
		introduce();
	}
	
     

	public static void main(String[] args) 
    {
	  MainClass jeopardy = new MainClass();
      while(jeopardy.running)
      {	
      try{
	    //these values can be changed from command lines!
	  /* 
	   	jeopardy.numRounds=Integer.parseInt(args[0]);//@param args[0] - the number of rounds per game
	   	jeopardy.numQuestions=Integer.parseInt(args[1]);// @param args[1] - the number of questions per round
	   	jeopardy.questionValue=Integer.parseInt(args[2]);// @param args[2] - the number of points per question
	    jeopardy.rightPercent=Double.parseDouble(args[3]);//@param args[3] - the percentage for the contestants
	     
	    */
		

  		System.out.println("....................................................................");
		System.out.println("....................Welcome to Jeopardy Game........................");
		System.out.println("....................................................................");

		System.out.println("Below are the results of contestants' computed numbers ");
	   
		
        contestant = new Contestant[jeopardy.numContestant];
		
          /*new Contestant(jeopardy,0).start();
			new Contestant(jeopardy,1).start();
			new Contestant(jeopardy,2).start();
			new Contestant(jeopardy,3).start();
			new Contestant(jeopardy,4).start();
			new Contestant(jeopardy,5).start();
			new Contestant(jeopardy,6).start();
			
			*/
        int i=0;

		//ExecutorService t=Executors.newCachedThreadPool();
		do	
			{
				 contestant[i]=new Contestant(jeopardy,i);
				 //t.execute(contestant[i]);
				
				 contestant[i].start();//starting a thread !
				 i++;
				 
			 }	 while(i<jeopardy.numContestant);//7 contestants threads will be created!
		
		//Annoucer thread will be created!
		new Thread(new Announcer(jeopardy)).start();//starting(initializing) announcer thread!
	    
	    
    	}catch(Exception e)
    	{
    		
    	    	 System.out.println("Errors passing argument values!");
    	    	 e.printStackTrace();
    	}
        //t.shutDown();
      
         //wait for 'enter'
		//new Scanner(System.in).nextLine();
	 	jeopardy.shutdown();
      }
	}
    //SYNCHRONIZED METHODS
	
	 public synchronized void increase_counterForContestant()
	 {
		 
		 counterForContestant++;
	 }
	 public synchronized void decrease_counterForContestant()
	 {
		 
		 counterForContestant--;
	 }
	 /*public synchronized int get_counterForContestant()
	 {
		 
		 return counterForContestant;
		 
	 }*/
	 public synchronized boolean get_counterForContestant()
	 {
		 //if counterForContestant == numContestant then return true;
		 return counterForContestant == numContestant;
		 
	 }
	 
	 public synchronized void set_counterForContestant(int counterForContestant)
	 {
		 this.counterForContestant= counterForContestant;
	 }

	  public synchronized void increase_counterForRound()
	  {
		  
		  counterForRound++;
	  }
	  
	  public synchronized void decrease_counterForRound()
	  {
		  
		  counterForRound--;
	  }
	   
	  public synchronized int get_counterForRound()//return the counter of contestants
	  {
			 
			 return counterForContestant;
	  }
		 
	  public synchronized void set_counterForRound(int counterForRound)
	   {
			 this.counterForRound= counterForRound;
	   }
	 
	  public synchronized boolean get_oksignalContestant()
	   {
		  	 return oksignalContestant;
	   }
	 
	 public synchronized void set_oksignalContestant()
	 {
		 
		 oksignalContestant=true;
		 
	 }
	 
	 public synchronized void reset_oksignalContestant()
	 {
		 
		 oksignalContestant=false;
		 
	 }
	 
	 public synchronized boolean get_oksignalAnnouncer()
	 {
		 
		 return oksignalAnnouncer;
		 
	 }
	 
	 public synchronized void set_oksignalAnnouncer()
	 {
		 
		 oksignalAnnouncer=true;
		 
	 }
	 
	 public synchronized void reset_oksignalAnnouncer()
	 {
		 
		 oksignalAnnouncer=false;
	 }

	 public synchronized boolean get_oksignalHost()
	 {
		 
		 return oksignalHost;
	 }
	 
	 public synchronized void set_oksignalHost()
	 {
		 oksignalHost = true;
	 }
	 
	 public synchronized void reset_oksignalHost()
	 {
		 oksignalHost = false;
     }
	
	 // synchronize on the object that is going to call wait on.
	public synchronized void Wait() throws InterruptedException
	{  
		  wait();
	}
	 // synchronize on the object that is going to call notify on.
	 public synchronized void Notify()
	 {
		  notify();
	 }
	 
	 public synchronized void NotifyAll() throws InterruptedException
	 {
		  notifyAll();
	 }
	 
	 public synchronized int get_priority()
	 {
		 return priority;
	 }
	 
	  public synchronized void set_priority()
	  {
		 
	 	 Thread.currentThread().setPriority(priority);
		 
	  }
	  		 
	  
	  public synchronized boolean get_endsignalRound()
	  {
		  
		  return endsignalRound;
		  
	  }


	  public synchronized void set_endsignalRound()
	  {
			endsignalRound=true;
	  }

	  public synchronized void reset_endsignalRound()
	  {
			endsignalRound=false;
	  }

	  public synchronized boolean get_oksignalFirst()
	  {
		  
		  return oksignalFirst;
	  }


		public synchronized void  set_oksignalFirst()
		{
			oksignalFirst=true;
			
		}

		public synchronized void  reset_oksignalFirst()
		{
			oksignalFirst=false;
			
		}
	  
	  public void shutdown()
		{
			running=false;
		}
		

		@SuppressWarnings("deprecation")
		public synchronized void suspend() 
		{
			Thread.currentThread().suspend();
		}
		
	    static Announcer announcer;
		static Contestant[] contestant;
		//important default vairables 
		int numContestant, numRounds, numQuestions, questionValues;
		double rightPercent;
		//counters
	    int counterForContestant,counterForRound;
	    int activeThread;//use for the host to determine which thread is active to answer question, in order to increase/decrease score
		
		//boolean variables created for synchronized methods.
		boolean oksignalContestant, oksignalAnnouncer,oksignalHost, endsignalRound, oksignalAnswer, oksignalFirst;
		public volatile boolean running;
		ExecutorService t; 
		int priority;//priority for contestants threads! 
	    //making CyclicBarrier variables, using CyclicBarrier class 
	    //in order to allows a set of Contestants threads to all wait for each other to reach a common barrier point
	    CyclicBarrier barrier1, barrier2;
	   
		//private ExecutorService t;
		
        //String method introduce will be shared among contestants to introduce themselves.!
		public String introduce() 
		{
	    	 return "Hello, EveryOne! I'm glad to be here. My name is ";
			
		}
        





}//end of MainClass

