package projectOne;
import java.util.Calendar;
import java.util.Random;
//import java.util.concurrent.TimeUnit.*;
//import java.util.concurrent.BrokenBarrierException;

//THIS IS 'Contestant' Thread CLASS
public class Contestant extends Thread 
{

	public long startingTime=getCurrentTime();
	Contestant(MainClass jeopardy,int id)
	{
		this.jeopardy = jeopardy;
		this.setName((new StringBuilder("Contestant ")).append(id).toString());
		
	}
	
	//the run method for the Host thread. 
	@SuppressWarnings("deprecation")
	public void run()
	{
		   	   
			   number = new Random().nextInt(200);//contestants generating random numbers			
			 //using counter to check they are done with computing!
			   jeopardy.increase_counterForContestant();
			   try{
			     sleep(300);
			      PrintMessage("Hi..my computed number is "+number);
		       }catch(InterruptedException e)
	     	 { System.out.println( Thread.currentThread()+" gets interrupted!");}
			
			//checking if contestants done with computing their numbers!						
			if(jeopardy.get_counterForContestant())
			{		
				jeopardy.set_oksignalContestant();	
				// okSignalContestants=true;
				
				//then, Announcer will stop busy waiting and start finding out the contstants 
				//with three hightest numbers.
			
			}	
			//now contestants are done with computing their numbers.		
			//so they are waiting for Announcer to annouce who is rejected or selected
			do{
				try {
						sleep(30);
			     	} catch (InterruptedException e) 
				    {
					  e.printStackTrace();
			    	}
			}while(!jeopardy.get_oksignalAnnouncer());//bw til oksignalAnnoucer is set to 'true' by Annoucer!
			
			
			
			//selected contestants will sleep for random time.
			try {
				Thread.sleep(new Random().nextInt(1000)+4000);
			} catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
			//they will wait for each other before setting priority.                    
            try {
				jeopardy.Wait();
			} catch (InterruptedException e2) 
			{
				e2.printStackTrace();
			}

            // contestants start to introduce individually from the highest to lowest priority!
            jeopardy.get_priority();//get priority
            jeopardy.set_priority();//set priority for each contestant!
            try {
				 sleep(10000);
				 NamePrintMessage(jeopardy.introduce());//indroducing individually
			} catch (InterruptedException e1) 
			{
				e1.printStackTrace();
			}
           
            //once a contestant is done introducing, he will reset his priority back to deafult
            //and let another contestant introduce himself by executing yield();
		    Thread.yield();
		  //waiting contestants gets notified by Announcer that it's time to start the game.    
		  //reseting all the 3 conestants, one at a time. otherwise, they will get stuck!
		    jeopardy.barrier1.reset();
		    //after that they all will be waiting to continue to start the game!
		    //a contestant will be randomly notified by host to answer a question!
            try 
            {
				jeopardy.Wait();
			} 
            catch (InterruptedException e1) 
			{
				
				e1.printStackTrace();
			}
            //once a contestant gets notified by the host to answer, he'll answer!
            do
            {
            	// A contestant picks his choice
            	PrintMessage("[Contestant answering question!] I pick no-"+new Random().nextInt(2)+ " for answer");
            	//keeps the active Index no!
            	jeopardy.activeThread=indexNo;//current active thread!
            	//oksignalAnswer indicates answer is just replied!
            	//so that host can get out of busy waiting 
            	jeopardy.oksignalAnswer=true;
            	try {
					jeopardy.Wait();//waiting to answer for next question.
				} catch (InterruptedException e) 
				{
					
					e.printStackTrace();
				}
            	
            }while(!jeopardy.get_endsignalRound());
            

 		   //at this point, all rounds have been played...endsignalRound is set to 'true'
 	       //it is time for Final jeopardy. The Contestant
		  // will randomly choose the amount to wager (determined from 0 to the contestant's score
           //If the Contestant does not have enough money (negative balance), 
            //have him say goodbye and terminate.
                 
          //contestant who has zero or negative balance will say good bye to the host
        	//PrintMessage("(who has negative or zero score) says 'Good Bye' to the host ");
            if(scorePoint<=0)
            {
            	PrintMessage("[total score="+scorePoint+"][ Contestant saying 'Good Bye' and terminate]");
            	//after printing out the score! the constant will be released.
                //jeopardy.suspend();
                Thread.currentThread().suspend();//those who got negative score got suspended!
                jeopardy.barrier2.reset();
                jeopardy.shutdown();
            }
            if (scorePoint>0)//those constants who got score above 0
            
            {
            	if(Thread.currentThread().isAlive())
            	{		
            		wagerAmount = new Random().nextInt(scorePoint);
            		PrintMessage("[total score="+scorePoint+"] Contestant choosing "+wagerAmount);
            		//after printing out the score! the constant will be released.
            		jeopardy.barrier2.reset();
            	}
            }
            

 		   //contestants with positive balance will busy wait for final question.
            try {
				jeopardy.Wait();
			} catch (InterruptedException e1) 
			{
				
				e1.printStackTrace();
			}
            //in order to think about the question the Contestants will SLEEP 
            //for a fixed amount of time.
            try {
				sleep(7000);
			} catch (InterruptedException e) 
			{
				
				e.printStackTrace();
			}
            //The first Contestant that wakes up will let host know that
            //the question is answered.

           // jeopardy.reset_oksignalHost();
            if(jeopardy.get_oksignalFirst())//if oksignalFirst==true then do the follwing
            {
            	jeopardy.reset_oksignalFirst();//reset oksignalFisrt to 'false'
            	PrintMessage("Contestant has answered the final question");
            	try{
            		sleep(100);
            	    jeopardy.Notify();//those who answer can get out from busy waiting
            }catch(Exception e){}
            	//  jeopardy.set_oksignalHost();
          /*  try
         	{
     	     	sleep(100);
     	    	jeopardy.NotifyAll();//notify the contestant
        	}catch(Exception e){}*/

            }      // Thread.currentThread().suspend();
            jeopardy.shutdown();
		   
	}//end of run() method of Contestant
	
	public long getCurrentTime()
	{
		return System.currentTimeMillis();
	}
	public synchronized void NamePrintMessage(String m)
	{
		String[] name={"David","Steven","Eric","Lily", "Tony","Jacob","Susan","William","Bob","Tyson"};
		int rand = new Random().nextInt(9);	
	
		System.out.print("[Printing From]"+getName()+"[time="+timeTracker()+"][age= "+age()+"]"+m+name[rand]+"\n" );
		
	

	}
	

	public synchronized void PrintMessage(String m)
	{
		
		System.out.println("[Printing From]"+getName()+"[time="+timeTracker()+"][age="+age()+"]"+m+"\n");
		
	}
	
	public long age()
	{
		return  System.currentTimeMillis()-startingTime;
	}

	public String timeTracker()
	{
	//initialize time variables and get the current time:
		String time=null;
		int hour=0, minute=0, second=0, millisecond=0;
		Calendar currentTime = Calendar.getInstance();
		currentTime.setTimeInMillis(System.currentTimeMillis());
		//set the variables to the current time
		hour=currentTime.get(Calendar.HOUR);
	    if(hour==0)
    	{ 	hour=12; 	}
	    minute=currentTime.get(Calendar.MINUTE);
	    second=currentTime.get(Calendar.SECOND);
	    millisecond=currentTime.get(Calendar.MILLISECOND); 
	
	    //calculate the hour
		if(hour<10)
		{ 	time=("0"+ hour);}
		else if(hour>=10)
		{	time=(""+hour);}
			time=time.concat(":");
			//calculate the minute:
		if(minute<10)
		{	time=time.concat("0"+minute);}
	
		else if(minute>=10)
		{	time=time.concat(""+minute);	}
			time=time.concat(":");
			//calculate the second:
		if(second<10)
		{	time=time.concat("0"+second); }
		else if(second>=10)
		{	time=time.concat(""+second); }
			time=time.concat(".");
			//calculate the millisecond
		if(millisecond<10)
		{	time=time.concat("0"+millisecond); }
		else if(millisecond>=10)
		{ 	time=time.concat(""+millisecond); }
			time=time.concat(" ");
			return time;
	}
	public int get_scorePoint()
	{
		return scorePoint;
	}
	
	public void set_scorePoint(int scorePoint)
	{
		this.scorePoint=scorePoint;
	}
	
	public void increase_scorePoint()
	{
		
		scorePoint = scorePoint + jeopardy.questionValues;
		
	}
	
	public void decrease_scorePoint()
	{
		
		scorePoint = scorePoint - jeopardy.questionValues;
		
	}
	public MainClass jeopardy;
	public int scorePoint=0;
	public int number, indexNo, wagerAmount;
	
		
	
	

}
