package projectOne;
import java.util.Calendar;
import java.util.concurrent.BrokenBarrierException;

//THIS IS 'Announcer' THREAD CLASS

public class Announcer implements Runnable
{
	
	public static long Startingtime = getCurrentTime();
	
	public Announcer(MainClass jeopardy)
	{		
		 this.jeopardy = jeopardy;
		 this.setName(name);
	}
	private String getName()//access to name, get(return) name!
	{
			return name;
	}				
					
	private void setName(String name) //access to name, set name!
	{
		this.name=name;
	}
	

	@SuppressWarnings("deprecation")
	//the run method for the Announcer thread. 
	public void run()
	{
		
			//currently contestants are running and computing their numbers!
		    //so that 'Announcer" is busywaiting for them, 
		    //thus, waiting for signal that contestants are done with computing
		    //and ready for get selected or rejected!
	
			do
			{	
				
				try {
					Thread.sleep(150);//busy waiting for contestants.
				} catch (InterruptedException e) 
				{
					System.out.println("Announcer gets interrupted from sleep");
				}
               //while condition will not be satisfied, 
				//when 'checkOKsignalContestants' return 'okSingalContestants=true' set by contestants.
			 }while(!jeopardy.get_oksignalContestant());
			
		    //sorting contestants 
			
			for (int i=0; i<jeopardy.numContestant; i++) 
			{
		        for (int k=i+1; k<jeopardy.numContestant; k++)
		        {
		            if (MainClass.contestant[i].number > MainClass.contestant[k].number) 
		            {
		                //exchanging 
		                Contestant temp = MainClass.contestant[i];
		               MainClass.contestant[i] = MainClass.contestant[k];
		               MainClass.contestant[k] = temp;
		            }
		        }
		    }	
		
			
			//first annouce who gets eliminated!
			int eliminated=0;
			do 
			{
				
				PrintMessage("Sorry.."+MainClass.contestant[eliminated].getName()+"...You are ELIMINATED! ");
				
				//MainClass.contestant[i].jeopardy.shutdown();
				MainClass.contestant[eliminated].suspend();
				//System.out.println("index: "+i+" "+jeopardy.contestant[i].threadIndex);
				eliminated++;
			}while(eliminated<4);
			//annouce who get selected..
			int selected=jeopardy.numContestant-1;
			do
			{
				PrintMessage("Congrats.."+MainClass.contestant[selected].getName()+"...You are SELECTED! ");
				
				MainClass.contestant[selected].indexNo=selected; //
				selected--;
			}while(selected>3);
			
			//set oksignalAnnoucer to be 'true'..so that contestants can move on!
			jeopardy.set_oksignalAnnouncer();
			
			//set oksignalContestant to 'false'
			jeopardy.reset_oksignalContestant();
			
			PrintMessage("Ladies and Gentlemen! My name is David, your announcer and Welcome to Jeopardy Game.. ");
		
			Thread host=new Thread(new Host(jeopardy));//starting(initializing host thread)
			
			host.start();
			
			try {
				Thread.sleep(6000);
			} catch (InterruptedException e)
			{
				e.printStackTrace();
			}
			
			jeopardy.reset_oksignalAnnouncer();
			
			PrintMessage("It's time to welcome our host..Mr.Thomas!!");
			//Announcer lets host know that time for the game to begin by interrupting
			host.interrupt();
			//oksignalAnnoucer is orignally set to 'false' so that
			//Announcer will busy wait until it's set to 'true' by host!
			do
			{
				try {
					Thread.sleep(150);
				} catch (InterruptedException e)
				{
					System.out.print("Announcer gets intterrupted from sleep");
				}	
			}while(!jeopardy.get_oksignalAnnouncer());
			//oksignalAnnouccer is set to 'true' now by host, Annoucer continues saying as follows
			PrintMessage("Alirghty!...Contestants! Why don't you introduce yourself? ");
			
			
			//Annoucer notifies all the contestants who have been waiting by wait system call.
			try {
				jeopardy.NotifyAll();
			} catch (InterruptedException e1)
			{
				e1.printStackTrace();
			}
			
			//using cyclicbarrier's await() call, 
			
			//all of 3 contestants are waiting for their chances to introduce themselves
			// a contestant will be release from waiting when called by cyclicbarrier's reset
			
			try {
				try {
					jeopardy.barrier1.await();
				} catch (BrokenBarrierException e) 
				{
					{};
				}
			} catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//at this point, all the contestants are done introducing by reset() call.
			//so that, Announcer will say 'start
			
			PrintMessage("Alright!! Since the contestants are done introducing! Mr.thomas..let's start the show");
			//will set oksignalHost to 'true' so that host can contiue starting round, asking questions.
			jeopardy.set_oksignalHost();
			//Announcer has done his job, time to terminate!
			PrintMessage("[Announcer has terminated]");
			Thread.currentThread().suspend();		
					
	}//end of run() method for Announcer
	
	//this method gives current time in milliseconds.
	public static long getCurrentTime()
	{
		return System.currentTimeMillis();
	}
	//printing (msg) method!
	public void PrintMessage(String m)
	{
		
		System.out.println("[Printing From]"+getName()+"[time="+timeTracker()+"][age="+age()+"]"+m+"\n");
		
	}
	
	//age() method which keeps track of Threads age.
	public long age()
	{
		return  System.currentTimeMillis()-Startingtime;
	}
	
	//timeTracker() method which keeps track of time.

	public String timeTracker()
	{
	//initialize time variables and get the current time:
		String time=null;
		int hour=0, minute=0, second=0, millisecond=0;
		Calendar currentTime = Calendar.getInstance();
		currentTime.setTimeInMillis(System.currentTimeMillis());
		//set the variables to the current time
		hour=currentTime.get(Calendar.HOUR);
	    if(hour==0)
    	{ 	hour=12; 	}
	    minute=currentTime.get(Calendar.MINUTE);
	    second=currentTime.get(Calendar.SECOND);
	    millisecond=currentTime.get(Calendar.MILLISECOND); 
	
	    //calculate the hour
		if(hour<10)
		{ 	time=("0"+ hour);}
		else if(hour>=10)
		{	time=(""+hour);}
			time=time.concat(":");
			//calculate the minute:
		if(minute<10)
		{	time=time.concat("0"+minute);}
	
		else if(minute>=10)
		{	time=time.concat(""+minute);	}
			time=time.concat(":");
			//calculate the second:
		if(second<10)
		{	time=time.concat("0"+second); }
		else if(second>=10)
		{	time=time.concat(""+second); }
			time=time.concat(".");
			//calculate the millisecond
		if(millisecond<10)
		{	time=time.concat("0"+millisecond); }
		else if(millisecond>=10)
		{ 	time=time.concat(""+millisecond); }
			time=time.concat(" ");
			return time;
		}
	
	public MainClass jeopardy;
	private String name = "Announcer";

	
}//end of class 'Announcer'

