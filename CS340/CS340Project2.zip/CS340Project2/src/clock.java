import java.util.concurrent.Semaphore;

public class clock extends Thread {

	final static long startTime = System.currentTimeMillis();
	private static int sessionId = 1;
	
	//semaphores to put threads into for session 1 and session 1
	public static Semaphore session1 = new Semaphore(0);
	public static Semaphore session2 = new Semaphore(0);

	public clock() {
		super("clock");
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		//notify the visitor that session 1 has started
		sessionStarts();
		
		//release all the threads in session 1 sempahore
		for(int i = 0; i < 15; i++){
			v(session1);
		}
		
		//sleep for movie
		speaker.littleSleep(200);
		
		sessionEnds();
		
		//reset the seat number in visitors
		//visitors.setSeatNumber(0);
		sessionId++;
		
		//release all the threads inside session 1 and go to museum
		for(int i = 0; i < visitors.museum.getQueueLength(); i++){
			v(visitors.museum);
		}
		
		//break between sessions
		speaker.littleSleep(500);
		
		//notify that session 2 has started
		sessionStarts();
		
		//release all the threads in session 2 semaphores
		for(int i = 0; i < 9; i++){
			v(session2);
		}
		
		//little sleep for speaker's presentation
		speaker.littleSleep(200);
		
		//session 2 has ended
		sessionEnds();
		
		//release the threads that got into session 2 and go to museum
		for(int i = 0; i < visitors.museum.getQueueLength(); i++){
			v(visitors.museum);
		}
		
		//sleep until the end of day 
		speaker.littleSleep(500);
		
		System.out.println("---------------------End Of Day---------------------");
		
		visitors.endOfDay.release(15);
		
	}
	
	
	//semaphore hold function so I don't have to keep on writing try and catch
	public static void p(Semaphore x){
		try {
			x.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//semaphore release function
	public static void v(Semaphore x){
		x.release();
	}
	
	//function to print out session start
	public static void sessionStarts(){
		System.out.println("[" + clock.age() + "]" + " ---------------------Session " + sessionId + " starts---------------------");
	}

	//function to print out session ends
	public static void sessionEnds(){
		System.out.println("[" + clock.age() + "]" + " ---------------------Session " + sessionId + " ends---------------------");
	}
	
	//return sessionId
	public static int getSession() {
		return sessionId;
	}
	
	// return clock time
	public static long age() {
		return System.currentTimeMillis() - startTime;
	}

}
