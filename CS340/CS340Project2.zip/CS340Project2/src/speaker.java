import java.util.concurrent.Semaphore;

public class speaker extends Thread {
	
	//puts the speaker into start semaphore until its get release
	public static Semaphore start = new Semaphore(0);
	private final int maxSeat = 6;

	public speaker(String x) {
		super(x);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("[" + clock.age() + "] " + getName()
				+ " arrives Ellis Island and waits in the lobby.");

		// holds the process until its time to present
		clock.p(start);

		// speaker starts the presentation
		presentationStart();

		// little sleep interval for the presentation
		littleSleep(50);

		// the presentation is finish
		presentationFinished();

		// the movie for session 1 starts
		movieStart();
		
		for (int i = 0; i < maxSeat; i++) {
			clock.v(visitors.movie);
		}
		
		//hold the process until session 2 presentation start
		clock.p(start);
		
		//speaker starts presentation 2
		presentationStart();
		
		//little sleep interval for the presentation
		littleSleep(50);
		
		//the presentation is finish
		presentationFinished();
		
		//the movie start for session 1
		movieStart();
		
		//release all the threads in movie semaphores for them to watch movie
		for(int i = 0; i < visitors.movie.getQueueLength(); i++){
			clock.v(visitors.movie);
		}
		
		System.out.println("[" + clock.age() + "] " + getName() + " leaves the museum");
		
		
		
	}

	public void movieStart() {
		System.out.println("[" + clock.age() + "] "
				+ "Movie Starts for session " + clock.getSession());
	}

	public void movieFinished() {
		System.out.println("[" + clock.age() + "] "
				+ "Movie Finishes for session " + clock.getSession());
	}

	public void presentationStart() {
		System.out.println("[" + clock.age() + "] " + getName()
				+ " is giving presentation for session " + clock.getSession());
	}

	public static void presentationFinished() {
		System.out.println("[" + clock.age() + "] " + "Presentation for "
				+ clock.getSession() + " is finished");
	}

	// sleep method so I don't have to
	// write try and catch over and over
	public static void littleSleep(int x) {
		try {
			sleep(x);
		} catch (InterruptedException e) {
		}
	}

}
