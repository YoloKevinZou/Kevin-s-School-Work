import java.util.concurrent.Semaphore;

public class visitors extends Thread {

	private static int seatNumber = 0;
	private static int group = 0;
	private static int count = 0;
	
	//puts the thread thats going to museum into this semaphore
	public static Semaphore museum = new Semaphore(0);
	
	//mutex for critical session
	private static Semaphore mutex = new Semaphore(1);
	
	//puts the thread thats going to watch movie into this semaphore
	public static Semaphore movie = new Semaphore(0);
	
	//put all thread into this semaphore when its end of the day
	public static Semaphore endOfDay = new Semaphore(0);
	
	//group when the visitors are about to leave
	public static Semaphore groupBy = new Semaphore(0);
	

	public visitors(int i) {
		// TODO Auto-generated constructor stub
		super("Visitor-" + i);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		// message ("entered ellis island.");
		enterLobby();

		// put the threads into sesson 1 semaphores for the seat
		clock.p(clock.session1);

		// hold for mutex semaphores
		clock.p(mutex);
		seatNumber++;
		
		// check if they take the seat for session 1
		if (takeSeat()) {
			
			clock.v(mutex);
			
			// enter session for threads that got into session
			enterSession();
		
			//display the messages when the are watching sessions
			gotIn();

		}
		
		// if they didn't get seat for session 1
		else {
			
			leaveRoom();
			
			//if all the people enter or leave the room, tells speaker to start presentation
			if(seatNumber==15){
				clock.v(speaker.start);
				seatNumber = 0;
			}
			
			//release mutex
			clock.v(mutex);

			// put the threads into session 2 semaphore
			clock.p(clock.session2);
			
			//mutex semaphore for session 2
			clock.p(mutex);
			seatNumber++;
			
			//clock.v(mutex);
			// check if they take the seat for session 2
			if (takeSeat()) {
				
				clock.v(mutex);
				
				//display that they enter the session
				enterSession();
				
				gotIn();
				
			}
			
			//if they did not get a seat for session 2
			else {
				
				if(clock.session2.getQueueLength()==0)
					System.out.println("[" + clock.age() + "] " + getName() + " told the next person on that there are no more session and goes to museum");
				else{
					System.out.println("[" + clock.age() + "] " + getName() + " no more person on line and goes to museum");
				}
				
				//if all the people enter or leave the room, tells speaker to start presentation
				if(seatNumber==9){
					clock.v(speaker.start);
				}
				
				clock.v(mutex);
					
				clock.v(clock.session2);
			}
			
		}
		
		//put into end of day semaphores
		clock.p(endOfDay);
		
		clock.p(mutex);
		group++;
		
		//for last group
		if(group==15){
			count++;
			clock.v(mutex);
			groupBy.release(2);
		}
		
		//if the group is not form the thread gets block into a group by semaphore
		else if(group%4!=0){
			clock.v(mutex);
			clock.p(groupBy);
		}
		
		//if group of 4 is form they can leave
		else{
			count++;
			clock.v(mutex);
			groupBy.release(3);
		}
		
		System.out.println("[" + clock.age() + "] " + getName() + " leaves the museum with group: " + count);
			
	}

	public void gotIn() {

	
		// put the thread into movie semaphore to wait for the movie to start
		clock.p(movie);
		watchMovie();

		// puts the thread into museum semaphores
		clock.p(museum);
		gotoMuseum();

	}

	//determine if the thread got a seat for the session
	public static boolean takeSeat() {
		if (seatNumber < 7) {
			return true;
		} else
			return false;
	}

	public static void setSeatNumber(int x) {
		seatNumber = x;
	}

	public void enterSession() {
		System.out.println("[" + clock.age() + "] " + getName()
				+ " enters the session " + clock.getSession());
	}

	public void leaveRoom() {
		System.out.println("[" + clock.age() + "] " + getName()
				+ " leaves the room");
	}

	// prints out the thread that enter lobby and increment the allArriveLobby
	public void enterLobby() {

		System.out.println("[" + clock.age() + "] " + getName()
				+ " arrives Ellis Island and waits in the lobby.");
	}

	// prints out the thread that goes to museum
	private void gotoMuseum() {
		System.out.println("[" + clock.age() + "] " + getName()
				+ " goes to the museum");
	}

	// prints out the thread that are watching the movie
	private void watchMovie() {
		System.out.println("[" + clock.age() + "] " + getName()
				+ " is watching the movie");
	}

}
