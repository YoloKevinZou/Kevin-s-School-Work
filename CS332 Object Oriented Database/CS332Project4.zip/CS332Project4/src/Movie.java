import java.util.*;
import javax.jdo.*;
import com.objectdb.Utilities;

@javax.jdo.annotations.PersistenceCapable

public class Movie
{
	String title;
	int releaseYear;

	Studio studio; // The studio that made this movie
	Director director; // The director of this movie

	HashSet<Actor> actors = new HashSet<Actor>();
	//The set of actors who acted in this movie

	public String toString()
	{
		return title+" "+releaseYear;
	}

	public static Collection<Movie> sameTitle(Query q){
		
		/* Returns the collection of all movies each of which has at least
		   one other movie with the same title. */
		
		q.setClass(Movie.class);
		q.declareVariables("Movie m");
		q.setFilter("this.title = m.title && this != m");

        return (Collection<Movie>) q.execute();

	}

	public static Collection<Movie> studioActors(String sName, int x, Query q){
		
		q.setClass(Movie.class);
		q.declareParameters("String sName, int x");
		q.setFilter("this.studio.name = sName && this.actors.size() >= x");
		/* Returns the collection of all movies "m" such that "m" was made by the studio with
		   the name "sName" and had at least "x" actors acting in it. */
		
		return (Collection<Movie>) q.execute(sName,x);
	}

	

	public static Collection<Movie> madeByDirectorBetweenTheseYears(Director d, int y1, int y2, Query q){
		

		/* Returns the collection of all movies made by the director "d" 
		   between the years "y1" and "y2", inclusive. It is assumed y1 <= y2. */
		
		q.setClass(Movie.class);
		q.declareParameters("Director d, int y1, int y2");
		q.setFilter("this.director = d && this.releaseYear >= y1 && this.releaseYear <= y2");
		
		return (Collection<Movie>) q.execute(d,y1,y2);
	}


	public static void main(String argv[])
	{
		PersistenceManager pm = Utilities.getPersistenceManager( "movie.odb" );

		System.out.println( "-- TEST find in Studio --\n" );
		Studio queens = Studio.find( "Queens Indie Film", pm );
		Studio cent = Studio.find( "21st Century Film", pm );

		System.out.println( queens );
		System.out.println( cent );
		System.out.println();

		System.out.println( "-- TEST studiosWithThisActor in Studio --\n" );
		Query q = pm.newQuery();
		Collection<Studio> ss = Studio.studiosWithThisActor("Cathleen Beckham", q);
		Utility.printCollection( ss );
		q.closeAll();
		System.out.println();

		System.out.println( "-- TEST studiosMinimumActors in Studio --\n" );
		q = pm.newQuery();
		ss = Studio.studiosMinimumActors(2, q);
		Utility.printCollection( ss );
		q.closeAll();
		System.out.println();

		System.out.println( "-- TEST studiosInThisYear in Studio --\n" );
		q = pm.newQuery();
		ss = Studio.studiosInThisYear(2000, q);
		Utility.printCollection( ss );
		q.closeAll();
		System.out.println();

		System.out.println( "-- TEST ActedBetweenTheseYears in Actor --\n" );
		q = pm.newQuery();
		Collection<Actor> aa = Actor.ActedBetweenTheseYears(2005, 2008, q);
		Utility.printCollection( aa );
		q.closeAll();
		System.out.println();

		System.out.println( "-- TEST actedForThisStudio in Actor --\n" );
		q = pm.newQuery();
		aa = Actor.actedForThisStudio("Cinema Universals", q);
		Utility.printCollection( aa );
		q.closeAll();
		System.out.println();

		System.out.println( "-- TEST movies in Director --\n" );
		Director d = Director.find("John Ford", pm);
		q = pm.newQuery();
		Collection<Movie> mm = d.movies(q);
		Utility.printCollection( mm );
		q.closeAll();
		System.out.println();

		System.out.println( "-- TEST studiosWithThisDirector in Director --\n" );
		q = pm.newQuery();
		ss = d.studiosWithThisDirector(q);
		Utility.printCollection( ss );
		q.closeAll();
		System.out.println();

		System.out.println( "-- TEST sameTitle --\n" );
		q = pm.newQuery();
		mm = sameTitle(q);
		Utility.printCollection( mm );
		q.closeAll();
		System.out.println();

		System.out.println( "-- TEST studioActors --\n" );
		q = pm.newQuery();
		mm = studioActors("Queens Indie Film", 2, q);
		Utility.printCollection( mm );
		q.closeAll();
		System.out.println();

		System.out.println( "-- TEST madeByDirectorBetweenTheseYears --\n" );
		q = pm.newQuery();
		mm = madeByDirectorBetweenTheseYears(d, 1970, 2005, q);
		Utility.printCollection( mm );
		q.closeAll();

		if ( !pm.isClosed() )
        		pm.close();
	}
}