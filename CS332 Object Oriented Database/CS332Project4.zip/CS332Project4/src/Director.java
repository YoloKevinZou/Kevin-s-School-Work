import java.util.*;

import javax.jdo.*;

@javax.jdo.annotations.PersistenceCapable
public class Director extends Person {

	public static Director find(String name, PersistenceManager pm) {


		/*
		 * Returns a director with the given "name"; if no such director exists,
		 * null is returned. The function is applied to the database held by the
		 * persistence manager "pm".
		 */
		
		Query q = pm.newQuery(Director.class);
		q.declareParameters("String name");
		q.setFilter("this.name == name");

		Collection<Director> ss = (Collection<Director>) q.execute(name);

		if (ss.isEmpty()) {
			q.close(ss);
			return null;
		}

		Director s = Utility.extract(ss);

		q.close(ss);
		return s;
	}

	public Collection<Movie> movies(Query q) {

		/*
		 * Returns the collection of all movies directed by this director.
		 * Represents the inverse of Movie.director.
		 */
		
		q.setClass(Movie.class);
		q.declareParameters("Director d");
		q.setFilter("this.director == d");

		return (Collection<Movie>) q.execute(this);
	}

	public Collection<Studio> studiosWithThisDirector(Query q) {
		
		//not done
		
		/*
		 * Returns the collection of all studios that have made at least two movies
		 * directed by this director.
		 */
		
		q.setClass(Studio.class);
		q.declareParameters("Director d");
		q.declareVariables("Movie m, m2");
		q.setFilter("this.movies.contains(m) && this.movies.contains(m2) && this.movies.director == d && m != m2 && m.director == d && m2.director ==d");
		return (Collection<Studio>) q.execute(this);
	}

}