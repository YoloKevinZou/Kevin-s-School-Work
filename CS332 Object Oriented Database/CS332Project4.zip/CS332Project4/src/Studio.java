import java.util.*;
import javax.jdo.*;

@javax.jdo.annotations.PersistenceCapable
public class Studio {
	String name; // key

	HashSet<Movie> movies = new HashSet<Movie>();

	// The set of movies made by this studio

	public String toString() {
		return name;
	}

	public static Studio find(String sName, PersistenceManager pm) {

		Query q = pm.newQuery(Studio.class);
		q.declareParameters("String sName");
		q.setFilter("this.name == sName");

		Collection<Studio> ss = (Collection<Studio>) q.execute(sName);

		Studio s = Utility.extract(ss);

		q.close(ss);
		
		return s;

	}

	/*
	 * Returns the studio with the given name "sName"; if no such studio exists,
	 * null is returned. The function is applied to the database held by the
	 * persistence manager "pm".
	 */

	public static Collection<Studio> studiosWithThisActor(String aName, Query q) {

		q.setClass(Studio.class);
		q.declareParameters("String aName");
		q.setFilter("this.movies.actors.name == aName");

		return (Collection<Studio>) q.execute(aName);

	}

	/*
	 * Returns the collection of all studios that have made at least one movie
	 * in which an actor with the name "aName" acted.
	 */

	public static Collection<Studio> studiosMinimumActors(int x, Query q) {

		q.setClass(Studio.class);
		q.declareParameters("int x");
		q.setFilter("this.movies.actors.size() >= x");

		return (Collection<Studio>) q.execute(x);
	}

	/*
	 * Returns the collection of all studios that have made a movie in which at
	 * least "x" actors acted.
	 */

	public static Collection<Studio> studiosInThisYear(int yr, Query q) {

		q.setClass(Studio.class);
		q.declareParameters("int yr");
		q.declareVariables("Actor a");
		q.setFilter("this.movies.size() >=1 && this.movies.releaseYear == yr && a.movies.releaseYear == yr && a.movies.studio.name != this.name");
		
		return (Collection<Studio>) q.execute(yr);
	}

	/*
	 * Returns the collection of all studios "s" that satisfy the following
	 * condition:
	 * 
	 * "s" has made at least one movie released in year "yr" that had an actor
	 * that acted in another movie which was released in the same year "yr" and
	 * was NOT made by the studio "s".
	 */
}