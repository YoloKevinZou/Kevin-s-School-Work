import java.util.*;
import javax.jdo.*;

@javax.jdo.annotations.PersistenceCapable

public class Actor extends Person
{
	HashSet<Movie> movies = new HashSet<Movie>();
	      // The set of movies in which this actor acted


	public static Collection<Actor> ActedBetweenTheseYears(int y1, int y2, Query q){
		
		q.setClass(Actor.class);
		q.declareParameters("int y1, int y2");
		q.setFilter("this.movies.releaseYear >= y1 && this.movies.releaseYear <= y2");
		
		return (Collection<Actor>) q.execute(y1,y2);
	}

	/* Returns the collection of all actors who acted in a movie 
	   made between the years "y1" and "y2", inclusive. It is assumed y1 <= y2. */

	public static Collection<Actor> actedForThisStudio(String sName, Query q){
		
		q.setClass(Actor.class);
		q.declareParameters("String sName");
		q.setFilter("this.movies.studio.name == sName");
		return (Collection<Actor>) q.execute(sName);
	}

	/* Returns the collection of all actors who acted in a movie made by
	   the studio with the name "sName". */
}