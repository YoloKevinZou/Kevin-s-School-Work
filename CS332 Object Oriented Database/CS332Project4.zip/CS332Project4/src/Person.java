@javax.jdo.annotations.PersistenceCapable

public class Person
{
	String name;


	public String toString()
	{
		return name;
	}
}