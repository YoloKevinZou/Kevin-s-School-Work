@javax.jdo.annotations.PersistenceCapable

public abstract class Person {
	
	protected int _pIDNum;
	protected String _pHomePhone;
	protected String _pGender;
	protected int _age;
	protected String _pFirst;
	protected String _pLast;
	
}