package POS;

import java.awt.Choice;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class CreateUserGUI extends JFrame {

	private JPanel contentPane;
	private FileMenuHandler fmh = new FileMenuHandler(this);
	public static boolean isOn = false;

	public CreateUserGUI() {
		setType(Type.UTILITY);
		setResizable(false);
		setTitle("Create Account");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 384, 243);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblUserName = new JLabel("User Name:");
		lblUserName.setHorizontalAlignment(SwingConstants.RIGHT);
		lblUserName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblUserName.setBounds(10, 28, 115, 34);
		contentPane.add(lblUserName);

		// textfield for username
		final JTextField textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(135, 28, 222, 34);
		contentPane.add(textField);

		// textfield for password
		final JTextField textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(135, 73, 222, 34);
		contentPane.add(textField_1);

		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPassword.setBounds(10, 73, 115, 34);
		contentPane.add(lblPassword);

		JLabel lblType = new JLabel("Type:");
		lblType.setHorizontalAlignment(SwingConstants.RIGHT);
		lblType.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblType.setBounds(10, 113, 115, 34);
		contentPane.add(lblType);

		final Choice choice = new Choice();
		choice.setFont(new Font("Tahoma", Font.PLAIN, 15));
		choice.setBounds(135, 120, 115, 25);
		contentPane.add(choice);
		choice.add("Normal");
		choice.add("Admin");

		JButton button_1 = new JButton("Cancel");
		button_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		button_1.setBounds(188, 170, 109, 38);
		contentPane.add(button_1);
		button_1.addActionListener(fmh);

		JButton btnCreate = new JButton("Create");
		btnCreate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCreate.setBounds(69, 170, 109, 38);
		contentPane.add(btnCreate);
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (textField.getText().isEmpty()
						|| textField_1.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null,
							"Missing Information, Please Re-Enter!");
					return;
				}

				//ConnectMYSQL dbconnect = new ConnectMYSQL();

				try {
					
					String username = textField.getText().toUpperCase();
					String password = textField_1.getText().toUpperCase();
					String atype = choice.getSelectedItem().toUpperCase();

					/*dbconnect.pst = dbconnect.con
							.prepareStatement("select * from accounts where username=?");
					dbconnect.pst.setString(1, username);
					dbconnect.rs = dbconnect.pst.executeQuery();

					// determine if the result set return is empty or not
					found = dbconnect.rs.next();*/

					// if the username existed, prompt the user to enter a new 1
					if (AccountCheck.accountExist(username)) {
						JOptionPane.showMessageDialog(null,
								"Username Existed, Please Enter a New One");
						textField.requestFocus();
						textField.selectAll();
						return;
					}
					
					//ask the user to input account username and password
					AccountCheck.accountInput();
						
					if(!AccountCheck.isAdmin(AccountCheck.username, AccountCheck.password)){
						return;
					}

					ConnectMYSQL dbconnect = new ConnectMYSQL();
					
					// insert the new created account into database
					dbconnect.pst = dbconnect.con
							.prepareStatement("insert into  accounts(username,password,atype) values (?, ?, ?)");
					dbconnect.pst.setString(1, username);
					dbconnect.pst.setString(2, password);
					dbconnect.pst.setString(3, atype);
					dbconnect.pst.executeUpdate();

					JOptionPane.showMessageDialog(null, "User Created!");
					setVisible(false);
					dbconnect.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 

			}

		});

	}
}
