package POS;

import java.awt.List;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class MenuListItemListener implements ItemListener {

	List list;

	public MenuListItemListener(List l) {
		list = l;
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		int index = (int) e.getItem();
		GUI.sellList.addItem(GUI.menuList.getItem(index));

		// set the tax number with updated values
		GUI.taxLabel.setText(TaxandTotal.computeTax(GUI.sellList));

		// set the total number with updated values
		GUI.totalLabel.setText(TaxandTotal.computeTotal(GUI.sellList));
	}

}
