package POS;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.Scanner;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

public class FileMenuHandler implements ActionListener {

	JFrame jframe;
	public static boolean isOn = false;
	public static JFrame form;

	public FileMenuHandler(JFrame jf) {
		jframe = jf;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		String buttonName = event.getActionCommand();

		// add new menu items
		if (buttonName.equals("Add Item")) {
			addItem();
		}

		// cancel button on the springforms
		else if (buttonName.equals("Cancel")) {
			cancel();
		}

		// remove item on main gui
		else if (buttonName.equals("Remove Item")) {
			removeItem();
		}

		// add member on main gui
		else if (buttonName.equals("Add Member")) {
			addMember();
		}

		// remove member on main gui
		else if (buttonName.equals("Remove Member")) {
			removeMember();
		}

		// find member on main gui
		else if (buttonName.equals("Find Member")) {
			findMember();
		}

		// import file on main gui
		else if (buttonName.equals("Import/Export File")) {
			importexport();
		}

		// sells report on main gui
		else if (buttonName.equals("Sells Report")) {
			sellsReport();
		}

		// create users on main gui
		else if (buttonName.equals("Create Users")) {
			createUsers();
		}

		// PAY on main gui
		else if (buttonName.equals("PAY")) {
			pay();
		}

		else if (buttonName.equals("View All Member")) {

			viewAllMember();
		}

	}

	private void importexport() {
		// TODO Auto-generated method stub
		formIsOn();
		tableIsOn();
		form = new ImportExport();
		ImportExport.isOn = true;
		form.setLocationRelativeTo(null);
		form.setVisible(true);

		
	}

	private void viewAllMember() {

		formIsOn();
		tableIsOn();
		TableGUI.viewAllMember();
		TableGUI.tableOn = true;

	}

	private void pay() {

		// display a message if the selllist is empty
		if (GUI.sellList.getItemCount() == 0) {
			JOptionPane.showMessageDialog(null, "Sells List is empty!");
			return;
		}

		ConnectMYSQL dbconnect = new ConnectMYSQL();

		// if the member id is inputted in the main gui
		// add the amount of money spend to reward point
		// 1 reward point per dollar spent
		if (!GUI.memberid.getText().isEmpty()) {

			// get the current reward point and add it by the total amount spend
			try {

				// make sure the memberid is in interger form
				int memberID;
				try {
					memberID = Integer.parseInt(GUI.memberid.getText());
				} catch (NumberFormatException ex) {
					JOptionPane.showMessageDialog(null, "Invalid Member ID!");
					return;
				}

				// check if the memberid exists
				// prompt the user to reenter if not valid
				if (!AccountCheck.memberIdIsValid(memberID)) {
					return;
				}

				dbconnect.pst = dbconnect.con
						.prepareStatement("select * from members where memberid=?");
				dbconnect.pst.setInt(1, memberID);
				dbconnect.rs = dbconnect.pst.executeQuery();

				int currentpoints = (int) Double.parseDouble(GUI.totalLabel
						.getText());
				int updatedpoints = 0;

				// update the value of the points
				while (dbconnect.rs.next()) {
					updatedpoints = Integer.parseInt(dbconnect.rs.getString(9))
							+ currentpoints;

				}

				// update the new value into database
				dbconnect.pst = dbconnect.con
						.prepareStatement("update members set rewardpoints=? where memberid=?");
				dbconnect.pst.setInt(1, updatedpoints);
				dbconnect.pst.setInt(2, memberID);
				dbconnect.pst.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		// add the sells record into database
		try {
			dbconnect.pst = dbconnect.con
					.prepareStatement("insert into  sells(sname,scost,sdate, username) values (?, ?,default, ?)");

			for (int i = 0; i < GUI.sellList.getItemCount(); i++) {
				String[] temp = GUI.sellList.getItem(i).split(" ");
				String name = temp[9].toUpperCase();

				// add taxes to the item before putting into database and limit
				// the decimal to 2
				double value = Double.parseDouble(temp[1]) * 1.08875;
				DecimalFormat df = new DecimalFormat("0.00");
				String cost = "";
				cost += df.format(value);

				dbconnect.pst.setString(1, name);
				dbconnect.pst.setString(2, cost);
				dbconnect.pst.setString(3, StartUp.loginName);

				dbconnect.pst.executeUpdate();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbconnect.close();
		}

		// when the pay is done, clear up the sells list
		if (GUI.sellList.getItemCount() != 0) {
			JOptionPane.showMessageDialog(null, "THANK YOU!");
			GUI.sellList.removeAll();
			GUI.totalLabel.setText("0.00");
			GUI.taxLabel.setText("0.00");
		}

		GUI.memberid.setText("");

	}

	private void createUsers() {

		formIsOn();
		tableIsOn();
		form = new CreateUserGUI();
		CreateUserGUI.isOn = true;
		form.setLocationRelativeTo(null);
		form.setVisible(true);

	}

	private void sellsReport() {
		formIsOn();
		tableIsOn();
		form = new SellsReportGUI();
		SellsReportGUI.isOn = true;
		form.setLocationRelativeTo(null);
		form.setVisible(true);

	}

	private void removeMember() {
		formIsOn();
		tableIsOn();
		form = new RemoveMemberGUI();
		RemoveMemberGUI.isOn = true;
		form.setLocationRelativeTo(null);
		form.setVisible(true);
	}

	private void findMember() {
		formIsOn();
		tableIsOn();
		form = new FindMemberGUI();
		FindMemberGUI.isOn = true;
		form.setLocationRelativeTo(null);
		form.setVisible(true);

	}

	private void addItem() {
		formIsOn();
		tableIsOn();
		form = new AddItemGUI();
		AddItemGUI.isOn = true;
		form.setLocationRelativeTo(null);
		form.setVisible(true);
	}

	private void addMember() {
		formIsOn();
		tableIsOn();
		form = new AddMemberGUI();
		AddMemberGUI.isOn = true;
		form.setLocationRelativeTo(null);
		form.setVisible(true);
	}

	private void removeItem() {

		if (GUI.menuList.getItemCount() == 0)
			return;

		if (GUI.menuList.getSelectedIndex() == -1) {
			JOptionPane.showMessageDialog(null,
					"Please select an item to remove!");
			return;
		}

		// split the strings in the list
		String temp = GUI.menuList.getItem(GUI.menuList.getSelectedIndex());
		String[] parts = temp.split(" ");

		double cost = Double.parseDouble(parts[1]);

		String name = "";

		// get the menu item name
		for (int i = 2; i < parts.length; i++) {
			if (!parts[i].isEmpty()) {
				name += parts[i] + " ";
			}
		}

		// remove the item from the database
		ConnectMYSQL dbconnect = new ConnectMYSQL();

		AccountCheck.accountInput();

		// prompt user to enter the username and password in order to remove
		// item
		if (!AccountCheck.isAdmin(AccountCheck.username, AccountCheck.password)) {
			dbconnect.close();
			return;
		}

		GUI.menuList.remove(GUI.menuList.getSelectedIndex());

		try {

			dbconnect.pst = dbconnect.con
					.prepareStatement("delete from menu where mname=? && mcost=?");
			dbconnect.pst.setString(1, name);
			dbconnect.pst.setDouble(2, cost);
			dbconnect.pst.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbconnect.close();
		}

	}

	public static void formIsOn() {

		if (AddItemGUI.isOn == true || AddMemberGUI.isOn == true
				|| RemoveMemberGUI.isOn == true || FindMemberGUI.isOn == true
				|| SellsReportGUI.isOn == true || CreateUserGUI.isOn == true||ImportExport.isOn==true) {
			form.dispose();
		}

	}

	public static void tableIsOn() {

		if (TableGUI.tableOn == true) {
			TableGUI.fm.dispose();
		}
	}

	private void cancel() {
		jframe.setVisible(false);
		isOn = false;
	}

	private void readSource(File chosenFile) {
		
		String error="The Following MemberID are not added\n";
		try {
				
			Scanner cin = new Scanner(chosenFile);

			ConnectMYSQL dbconnect = new ConnectMYSQL();

			while (cin.hasNext()) {

				String memberid, firstname, lastname, address, city, state, zip, dob, rewardPoints;

				//get each line in the file and split using delimiter ,
				String temp = cin.nextLine();
				String[] parts = temp.split(",");
				
				memberid = parts[0];
				firstname = parts[1];
				lastname = parts[2];
				address = parts[3];
				city = parts[4];
				state = parts[5];
				zip = parts[6];
				dob = parts[7];
				rewardPoints = parts[8];
				
				//insert the values into database
				try {
					dbconnect.pst = dbconnect.con
							.prepareStatement("insert into members(memberid,firstname,lastname,address,city,state,zip,dob,rewardpoints) value(?,?,?,?,?,?,?,?,?)");
					dbconnect.pst.setString(1, memberid);
					dbconnect.pst.setString(2, firstname);
					dbconnect.pst.setString(3, lastname);
					dbconnect.pst.setString(4, address);
					dbconnect.pst.setString(5, city);
					dbconnect.pst.setString(6, state);
					dbconnect.pst.setString(7, zip);
					dbconnect.pst.setString(8, dob);
					dbconnect.pst.setInt(9, Integer.parseInt(rewardPoints));
					dbconnect.pst.executeUpdate();
					dbconnect.close();
			
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					error+=e.getMessage() + "\n";
				}
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String chosenFileName = chosenFile.getName();
		JOptionPane.showMessageDialog(null, chosenFileName
				+ " has been loaded " + "\n");
		
		//print out the member id that was not added 
		JOptionPane.showMessageDialog(null, error);
		
	}//readfile

	private void openFile() {
		JFileChooser chooser;
		int status;
		chooser = new JFileChooser();
		status = chooser.showOpenDialog(null);

		if (status == JFileChooser.APPROVE_OPTION) {
			readSource(chooser.getSelectedFile());
		}

		else
			JOptionPane.showMessageDialog(null, "Open File dialog canceled");

	} // openFile
}
