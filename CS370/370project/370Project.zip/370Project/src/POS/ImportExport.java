package POS;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.Font;
import java.awt.Window.Type;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Scanner;

public class ImportExport extends JFrame {

	private JPanel contentPane;
	public static boolean isOn = false;
	private FileMenuHandler fmh = new FileMenuHandler(this);

	/**
	 * Create the frame.
	 */
	public ImportExport() {

		setType(Type.UTILITY);
		setResizable(false);
		setTitle("Import/Export Files");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 202, 197);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnImport = new JButton("Import");
		btnImport.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnImport.setBounds(34, 34, 117, 36);
		contentPane.add(btnImport);
		btnImport.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				openFile();
				setVisible(false);

			}
		});

		JButton btnExport = new JButton("Export");
		btnExport.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnExport.setBounds(34, 87, 117, 36);
		contentPane.add(btnExport);
		btnExport.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				outputfile();
				setVisible(false);

			}
		});
	}

	// export the member table in the database into a textfile
	private void outputfile() {

		ConnectMYSQL dbconnect = new ConnectMYSQL();

		try {
			PrintWriter writer = new PrintWriter("memberoutput.txt");

			try {
				dbconnect.pst = dbconnect.con
						.prepareStatement("select * from members");
				dbconnect.rs = dbconnect.pst.executeQuery();

				while (dbconnect.rs.next()) {
					writer.println(dbconnect.rs.getString(1) + ","
							+ dbconnect.rs.getString(2) + ","
							+ dbconnect.rs.getString(3) + ","
							+ dbconnect.rs.getString(4) + ","
							+ dbconnect.rs.getString(5) + ","
							+ dbconnect.rs.getString(6) + ","
							+ dbconnect.rs.getString(7) + ","
							+ dbconnect.rs.getString(8) + ","
							+ dbconnect.rs.getString(9));
				}

				writer.flush();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
			}
			writer.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JOptionPane.showMessageDialog(null, "File export successfully!");

	}

	private void readSource(File chosenFile) {
		
		String error = "";
		
		ConnectMYSQL dbconnect = new ConnectMYSQL();

		try {

			Scanner cin = new Scanner(chosenFile);

			while (cin.hasNext()) {

				String memberid, firstname, lastname, address, city, state, zip, dob, rewardPoints;

				// get each line in the file and split using delimiter ,
				String temp = cin.nextLine();
				String[] parts = temp.split(",");

				memberid = parts[0];
				firstname = parts[1];
				lastname = parts[2];
				address = parts[3];
				city = parts[4];
				state = parts[5];
				zip = parts[6];
				dob = parts[7];
				rewardPoints = parts[8];

				// insert the values into database
				try {
					dbconnect.pst = dbconnect.con
							.prepareStatement("insert into members(memberid,firstname,lastname,address,city,state,zip,dob,rewardpoints) value(?,?,?,?,?,?,?,?,?)");
					dbconnect.pst.setString(1, memberid);
					dbconnect.pst.setString(2, firstname);
					dbconnect.pst.setString(3, lastname);
					dbconnect.pst.setString(4, address);
					dbconnect.pst.setString(5, city);
					dbconnect.pst.setString(6, state);
					dbconnect.pst.setString(7, zip);
					dbconnect.pst.setString(8, dob);
					dbconnect.pst.setInt(9, Integer.parseInt(rewardPoints));
					dbconnect.pst.executeUpdate();

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					error += e.getMessage() + "\n";
				}

			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String chosenFileName = chosenFile.getName();
		JOptionPane.showMessageDialog(null, chosenFileName
				+ " has been loaded " + "\n");

		// print out the member id that was not added
		if (!error.isEmpty()) {
			JOptionPane.showMessageDialog(null, "The Following MemberID are not added\n" + error);
		}
		dbconnect.close();
	}// readfile

	private void openFile() {
		JFileChooser chooser;
		int status;
		chooser = new JFileChooser();
		status = chooser.showOpenDialog(null);

		if (status == JFileChooser.APPROVE_OPTION) {
			readSource(chooser.getSelectedFile());
		}

		else
			JOptionPane.showMessageDialog(null, "Open File dialog canceled");

	} // openFile
}
