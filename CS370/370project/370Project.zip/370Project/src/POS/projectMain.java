package POS;

public class projectMain {
	
	
	
	public static void main(String[] args){
		
		CreateDatabase cd = new CreateDatabase();
		GUI frame = new GUI();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		StartUp.starts();
		
	}
}
