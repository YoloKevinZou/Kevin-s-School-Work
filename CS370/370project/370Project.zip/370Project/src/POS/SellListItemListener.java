package POS;

import java.awt.List;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class SellListItemListener implements ItemListener {

	List list;
	public SellListItemListener(List l){
		list=l;
	}
	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		
		//remove the item on sell list when clicked
		int index = (int) e.getItem();
		GUI.sellList.remove(GUI.sellList.getItem(index));
		
		//set the tax number with updated values
		GUI.taxLabel.setText(TaxandTotal.computeTax(GUI.sellList));
		
		//set the total number with updated values
		GUI.totalLabel.setText(TaxandTotal.computeTotal(GUI.sellList));

	}


}
