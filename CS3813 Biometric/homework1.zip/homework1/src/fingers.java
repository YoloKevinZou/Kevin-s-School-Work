import java.awt.Point;
import java.awt.Polygon;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.lang.Math;

public class fingers {

	public static void main(String[] args) throws FileNotFoundException {

		List<List<Double>> distanceListFar = new LinkedList<List<Double>>();
		List<List<Double>> distanceListClose = new LinkedList<List<Double>>();

		fingerCheck("Finger0.txt", distanceListFar, distanceListClose);
		fingerCheck("Finger1.txt", distanceListFar, distanceListClose);
		fingerCheck("Finger2.txt", distanceListFar, distanceListClose);

		// prints out all the distances for each finger
		for (int i = 0; i < distanceListFar.size(); i++) {

			System.out.println("Finger " + (i));
			for (int j = 0; j < distanceListFar.get(i).size(); j++) {
				
				double furthest = (double) distanceListFar.get(i).get(j);
				double closest = (double) distanceListClose.get(i).get(j);
				System.out.printf("Furthest: %10f%20s%f\n", furthest, "Closest: ", closest);
			}
			System.out.println();
		}//ends for

		// calls the compare function for each finger
		for (int i = 0; i < distanceListFar.size(); i++) {

			for (int j = i + 1; j < distanceListFar.size(); j++) {
				if (!compare(distanceListFar.get(i), distanceListFar.get(j),
						distanceListClose.get(i), distanceListClose.get(j))) {
					System.out.println("Finger: " + i + " and Finger: " + j
							+ " are not identical");
				} else {
					System.out.println("Finger: " + i + " and Finger: " + j
							+ " are identical");
				}

			}
		}//ends for

	}

	public static boolean compare(List<Double> farDist1, List<Double> farDist2,
			List<Double> closeDist1, List<Double> closeDist2) {

		double farSum = 0;
		double farSum2 = 0;
		double closeSum = 0;
		double closeSum2 = 0;

		// two fingers have different number of segment inside polygon
		if (farDist1.size() != farDist2.size()) {
			return false;
		}

		// sum up the furthest and closest distance for ratio test
		for (int i = 0; i < farDist1.size(); i++) {
			farSum += (double) farDist1.get(i);
			farSum2 += (double) farDist2.get(i);
			closeSum += (double) closeDist1.get(i);
			closeSum2 += (double) closeDist2.get(i);
		}//ends for

		double ratio1 = 0;
		double ratio2 = 0;

		ratio1 = (farSum / farSum2);
		ratio2 = (closeSum / closeSum2);
		double ratioThreshold = 0.05;
		// check ratio, if the far and close ratio are not the same, they can't
		// be the same
		if ((Math.abs(ratio1 - ratio2)) > ratioThreshold) {
			return false;
		}

		// need to initialize temp linkedlist or else orginal 1 will be replace
		List<Double> fd1 = new LinkedList<Double>();
		List<Double> cd1 = new LinkedList<Double>();

		// adds the element from current linkedlist into the temporary
		for (int i = 0; i < farDist1.size(); i++) {
			fd1.add((double) farDist1.get(i));
			cd1.add((double) closeDist1.get(i));
		}//ends for

		// set the current distance 1 to new value obtained by multiplying the
		// ratio
		for (int i = 0; i < fd1.size(); i++) {
			double temp = ((double) farDist1.get(i)) * ratio2;
			double temp2 = ((double) closeDist1.get(i)) * ratio2;
			fd1.set(i, temp);
			cd1.set(i, temp2);
		}//end fors

		int count = 0;
		int distanceThreshold = 5;
		// check if the distances in 2 list matches
		// or under the threshold amount
		for (int i = 0; i < farDist1.size(); i++) {

			for (int j = 0; j < farDist1.size(); j++) {
				if ((Math.abs((double) fd1.get(i) - (double) farDist2.get(j))) < distanceThreshold
						&& (Math.abs((double) cd1.get(i)
								- (double) closeDist2.get(j))) < distanceThreshold) {
					count++;
				}
			}
		}//ends for

		if (count != farDist1.size()) {
			return false;
		}

		return true;

	}//ends function compare

	public static void fingerCheck(String filename,
			List<List<Double>> distanceListFar,
			List<List<Double>> distanceListClose) throws FileNotFoundException {

		File file = new File(filename);
		Scanner in = new Scanner(file);

		String finger = in.nextLine();
		System.out.println(finger);

		int leastX = 999, leastY = 999, maxX = 0, maxY = 0;

		List<Point> all = new LinkedList<Point>();

		int leastXY = 0, leastYX = 0, maxXY = 0, maxYX = 0;

		// store the coordinates into the linkedlist
		// get the minX, minY, maxX, maxY
		while (in.hasNext()) {

			int tempX = in.nextInt();
			int tempY = in.nextInt();

			if (tempX < leastX) {
				leastX = tempX;
				leastXY = tempY;
			}
			
			if (tempY < leastY) {
				leastY = tempY;
				leastYX = tempX;
			}

			if (maxY < tempY) {
				maxY = tempY;
				maxYX = tempX;
			}
			
			if (maxX < tempX) {
				maxX = tempX;
				maxXY = tempY;
			}

			all.add(new Point(tempX, tempY));
		}//ends while

		List<Point> boundary = new LinkedList<Point>();

		System.out.println("Boundary Points");

		// add the boundary points into the boundary list
		boundary.add(new Point(leastX, leastXY));
		boundary.add(new Point(leastYX, leastY));
		boundary.add(new Point(maxX, maxXY));
		boundary.add(new Point(maxYX, maxY));

		int[] axisX = new int[boundary.size()];
		int[] axisY = new int[boundary.size()];

		// put the boundary coordinates into array
		for (int i = 0; i < boundary.size(); i++) {
			axisX[i] = (int) boundary.get(i).getX();
			axisY[i] = (int) boundary.get(i).getY();

			System.out.println(axisX[i] + " " + axisY[i]);

		}//ends for

		Polygon poly = new Polygon(axisX, axisY, axisX.length);

		List<Point> insidePoly = new LinkedList<Point>();

		System.out.println();
		System.out.println("Points inside the polygon");

		// check if the points are inside the boundary points
		// adds the point into the insidePoly linkedlist
		for (int i = 0; i < all.size(); i++) {

			if (poly.contains((int) all.get(i).getX(), (int) all.get(i).getY())
					&& (int) all.get(i).getX() != axisX[0]
					&& (int) all.get(i).getY() != axisY[0]) {

				insidePoly.add(all.get(i));
			}

		}//ends for

		// prints out the coordinates that inside polygon
		for (int i = 0; i < insidePoly.size(); i++) {
			System.out.println((int) insidePoly.get(i).getX() + " "
					+ (int) insidePoly.get(i).getY());
		}

		double centroidX = 0, centroidY = 0;

		// adds everything form insidePoly linkedlist
		for (int i = 0; i < insidePoly.size(); i++) {

			centroidX += (double) insidePoly.get(i).getX();
			centroidY += (double) insidePoly.get(i).getY();

		}//ends for

		// adds everything from the boundary array
		for (int i = 0; i < axisX.length; i++) {

			centroidX += axisX[i];
			centroidY += axisY[i];

		}//ends for

		// gets the centroid point
		centroidX /= (insidePoly.size() + boundary.size());
		centroidY /= (insidePoly.size() + boundary.size());

		System.out.println();
		System.out.println("Centroid Points X: " + centroidX);
		System.out.println("Centroid Points Y: " + centroidY);

		List<Polygon2D> segments = new LinkedList<Polygon2D>();

		// create each segment with centroid
		for (int i = 0; i < axisX.length; i++) {

			double[] tempX = { axisX[i % axisX.length],
					axisX[(i + 1) % axisX.length], centroidX };
			double[] tempY = { axisY[i % axisX.length],
					axisY[(i + 1) % axisX.length], centroidY };

			segments.add(new Polygon2D(tempX, tempY, tempX.length));

		}//ends for

		System.out.println();

		List<Double> farDistanceList = new LinkedList<Double>();
		List<Double> closeDistanceList = new LinkedList<Double>();

		// print out the points that are in each segments
		for (int i = 0; i < segments.size(); i++) {

			// int closeX = 0, closeY = 0, farX = 0, farY = 0;
			double closeDistance = 999, farDistance = 0;

			System.out.println("Segments: " + (i + 1));

			// checks for the closest and furthest point in the segments
			for (int j = 0; j < all.size(); j++) {

				double distance = 0;
				// check for the points inside each segment. make sure the
				// boundary points are not in
				if (segments.get(i).contains((int) all.get(j).getX(),
						(int) all.get(j).getY())
						&& (int) all.get(j).getX() != axisX[i % axisX.length]
						&& (int) all.get(j).getX() != axisX[(i + 1)
								% axisX.length]
						&& (int) all.get(j).getY() != axisY[(i) % axisY.length]
						&& (int) all.get(j).getY() != axisY[(i + 1)
								% axisY.length]) {

					System.out.println((int) all.get(j).getX() + " "
							+ (int) all.get(j).getY());

					distance = Math
							.sqrt(((centroidX - (int) all.get(j).getX()) * (centroidX - (int) all
									.get(j).getX()))
									+ ((centroidY - (int) all.get(j).getY()) * (centroidY - (int) all
											.get(j).getY())));

					if (farDistance < distance) {
						farDistance = distance;
						// farX = (int) all.get(j).getX();
						// farY = (int) all.get(j).getY();
					}

					if (closeDistance > distance) {
						closeDistance = distance;
						// closeX = (int) all.get(j).getX();
						// closeY = (int) all.get(j).getY();
					}

				}

			}//ends inner for

			// store the far distance and close distance data into the linked
			// list
			farDistanceList.add(farDistance);
			closeDistanceList.add(closeDistance);
			System.out.println();
		}//ends outer for

		// adds the far distance and close distance into the main class list
		distanceListFar.add(farDistanceList);
		distanceListClose.add(closeDistanceList);

	}//ends function fingercheck
}
