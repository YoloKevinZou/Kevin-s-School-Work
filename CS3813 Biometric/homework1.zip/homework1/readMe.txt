I Splitted the data for the 3 fingers into 3 textfile Finger0.txt, Finger1.txt and Finger2.txt
In order for the program to work, these 3 files must in the project directory.
I used the in polygon api from java to determine if a point is actually inside the polygon.
In the Polygon 2d class, the contain function uses a ray tracing algorithm to determine if a point
is actually inside the polygon by returning the number of edges. if the return value is odd then
the point is inside the polygon, if the return edge is even then the point is outside of the polygon.
I used two types of comparision to determine if two fingers are identical. First I added up the furthest and
closest distances for 2 fingers and then compare the ratio, if the furthest ratio does not equal the closest ratio
the fingers are not identical, however they the ratios are equal or its lower then 0.05 threshold it will go on 
to the second test which it will multiple all the distances in 1 finger by the ratio differences and then compare
all the distances to the other finger. if the absolute value of two distance is less then 5 then it will move on 
and compare another distance. if all of them match then it will return true, else it will be false.